#!/usr/bin/env python3
"""Integra los ZIP del usuario sobre un checkout existente GRENALIVE sin perder módulos."""
from pathlib import Path
import argparse, json, shutil, sys, hashlib, os

HERE = Path(__file__).resolve().parent.parent


def replace_one(source, needle, replacement, label):
    if source.count(needle) != 1:
        raise RuntimeError(f'{label}: se esperó 1 coincidencia, hay {source.count(needle)}. Abortado para no romper GREÑA.')
    return source.replace(needle, replacement, 1)


def patch_overlay(s):
    s = replace_one(s, "src.theme==='minecraft'?'minecraft':'original'", "['minecraft','minecraft3d','domino'].includes(src.theme)?src.theme:'original'", 'overlay theme')
    s = replace_one(s,
        "root.innerHTML=cfg.theme==='minecraft'&&window.AfterglowMinecraft?window.AfterglowMinecraft.render(event,data,{platform:platformName[platform],giftSource:safeGiftSrc(data.giftImage),accent:palette[0]}):makeTemplate(event,data);\n  activateGiftArt();fitLongNames();\n  if(cfg.theme==='minecraft')window.AfterglowMinecraft?.prepare(root);",
        """const pack=window.GrenaThemePacks?.play(cfg.theme,event,data,{root,layout,platform:platformName[platform],raw:next,volume:cfg.volume,soundEnabled:cfg.soundEnabled&&cfg.sounds[event]&&['both',layout].includes(cfg.audioRoute)});
  if(!pack){
    root.innerHTML=(cfg.theme==='minecraft'||cfg.theme==='minecraft3d')&&window.AfterglowMinecraft?window.AfterglowMinecraft.render(event,data,{platform:platformName[platform],giftSource:safeGiftSrc(data.giftImage),accent:palette[0]}):makeTemplate(event,data);
    activateGiftArt();fitLongNames();
    if(cfg.theme==='minecraft'||cfg.theme==='minecraft3d')window.AfterglowMinecraft?.prepare(root);
  }""", 'overlay render')
    s = replace_one(s, "if(cfg.soundEnabled&&cfg.sounds[event]&&['both',layout].includes(cfg.audioRoute)){", "if(!pack&&cfg.soundEnabled&&cfg.sounds[event]&&['both',layout].includes(cfg.audioRoute)){", 'overlay avoid double sound')
    s = replace_one(s, "if(cfg.theme==='minecraft')window.AfterglowMinecraftSound?.play(event", "if(cfg.theme==='minecraft'||cfg.theme==='minecraft3d')window.AfterglowMinecraftSound?.play(event", 'overlay fallback sound')
    s = replace_one(s, "const ms=duration(event);const fx=root.firstElementChild;", "const ms=pack?.durationMs||duration(event);const fx=pack?null:root.firstElementChild;", 'overlay duration')
    s = replace_one(s, "</script></body></html>", "</script><script type=\"module\" src=\"/assets/grena-theme-packs.js?v=1\"></script></body></html>", 'overlay pack import')
    return s


def patch_studio(s):
    s = replace_one(s, '<option value="minecraft">Minecraft · PixelCraft 2.0</option>', '<option value="minecraft">Minecraft · PixelCraft 2.0</option><option value="minecraft3d">Minecraft · Cofre 3D (beta)</option><option value="domino">Dominó · Fichas animadas (beta)</option>', 'studio options')
    s = replace_one(s, "live.dataset.theme=$('#afterglowTheme').value==='minecraft'?'minecraft':'original'", "live.dataset.theme=$('#afterglowTheme').value", 'studio theme marker')
    old = "root.innerHTML=$('#afterglowTheme').value==='minecraft'&&window.AfterglowMinecraft?window.AfterglowMinecraft.render(current,s,{platform:platformName[platform],giftSource:safeGiftSrc(s.giftImage),accent:colorPair()[0]}):makeTemplate(current,s);activateGiftArt();fitLongNames();if($('#afterglowTheme').value==='minecraft')window.AfterglowMinecraft?.prepare(root);"
    new = """const theme=$('#afterglowTheme').value,layout=live.classList.contains('wide')?'horizontal':'vertical';const packed=window.GrenaThemePacks?.play(theme,current,s,{root,layout,platform:platformName[platform],volume:+$('#volume').value,soundEnabled:sound&&document.querySelector('[data-sound-for="'+current+'"]')?.checked!==false});if(!packed){root.innerHTML=(theme==='minecraft'||theme==='minecraft3d')&&window.AfterglowMinecraft?window.AfterglowMinecraft.render(current,s,{platform:platformName[platform],giftSource:safeGiftSrc(s.giftImage),accent:colorPair()[0]}):makeTemplate(current,s);activateGiftArt();fitLongNames();if(theme==='minecraft'||theme==='minecraft3d')window.AfterglowMinecraft?.prepare(root);}"""
    s = replace_one(s, old, new, 'studio render')
    s = replace_one(s, "const s=state(),dur=current==='raid'?6000:current==='likes'?4800:5500;", "const s=state();let dur=current==='raid'?6000:current==='likes'?4800:5500;", 'studio mutable duration')
    s = replace_one(s, "status.textContent='ANIMANDO / '+titles[current];beat(0);", "if(packed)dur=packed.durationMs;status.textContent='ANIMANDO / '+titles[current];beat(0);", 'studio duration')
    s = replace_one(s, "beatTimers.push(setTimeout(()=>root.firstElementChild?.classList.add('outro'),dur-680));", "if(!packed)beatTimers.push(setTimeout(()=>root.firstElementChild?.classList.add('outro'),dur-680));", 'studio outro')
    s = replace_one(s, "const player=$('#afterglowTheme').value==='minecraft'?window.AfterglowMinecraftSound:window.AfterglowAudio;", "const theme=$('#afterglowTheme').value;if((theme==='domino'||theme==='minecraft3d')&&window.GrenaThemePacks?.ready&&!(theme==='minecraft3d'&&type!=='gift'))return;const player=theme==='minecraft'||theme==='minecraft3d'?window.AfterglowMinecraftSound:window.AfterglowAudio;", 'studio sound')
    s = replace_one(s, "return {theme:$('#afterglowTheme').value==='minecraft'?'minecraft':'original'", "return {theme:$('#afterglowTheme').value", 'studio save')
    s = replace_one(s, "$('#afterglowTheme').value=v.theme==='minecraft'?'minecraft':'original';", "$('#afterglowTheme').value=['minecraft','minecraft3d','domino'].includes(v.theme)?v.theme:'original';", 'studio load')
    s = replace_one(s, '</script>\n</body></html>', '</script><script type="module" src="/assets/grena-theme-packs.js?v=1"></script>\n</body></html>', 'studio pack import')
    return s


def patch_alerts(s):
    s = replace_one(s, 'Solo dos estilos. Selecciona uno', 'Cuatro estilos. Selecciona uno', 'alert hub copy')
    needle = '  <span class="style-description">Tipografía pixelada, objetos de inventario, bloques, partículas, barra XP y sonidos de comer, recoger objetos y subir de nivel.</span>\n</button>'
    addition = '''\n<button type="button" class="style-choice" data-grena-theme="minecraft3d" aria-pressed="false">
  <span class="style-illustration minecraft" aria-hidden="true"><span class="pixel-block"></span><span class="logo-type">COFRE 3D</span></span>
  <span class="style-choice-name"><strong>Minecraft · Cofre 3D</strong><span>Elegir estilo</span></span>
  <span class="style-description">Regalos con cofre animado. Otros eventos conservan PixelCraft 2.0.</span>
</button>
<button type="button" class="style-choice" data-grena-theme="domino" aria-pressed="false">
  <span class="style-illustration afterglow" aria-hidden="true"><span class="logo-type">DOMINÓ ◉</span></span>
  <span class="style-choice-name"><strong>Dominó · Fichas animadas</strong><span>Elegir estilo</span></span>
  <span class="style-description">Seguidores, regalos, subs, raids, compartidos y likes con fichas animadas.</span>
</button>'''
    return replace_one(s, needle, needle + addition, 'alert hub cards')


def patch_picker(s):
    s = replace_one(s, "theme=value==='minecraft'?'minecraft':'original';", "theme=['minecraft','minecraft3d','domino'].includes(value)?value:'original';", 'theme picker')
    s = replace_one(s, "status.textContent=(theme==='minecraft'?'Minecraft activado':'Original activado')+' · Ambos enlaces OBS se actualizaron.';", "status.textContent=({minecraft:'Minecraft PixelCraft',minecraft3d:'Minecraft Cofre 3D',domino:'Dominó',original:'Original'}[theme]||'Original')+' activado · Ambos enlaces OBS se actualizaron.';", 'theme status')
    return s


def patch_server(s):
    return replace_one(s, "theme:x.theme==='minecraft'?'minecraft':'original'", "theme:['minecraft','minecraft3d','domino'].includes(x.theme)?x.theme:'original'", 'server settings normalization')


def patch_package(s):
    config = json.loads(s)
    config['name'] = 'grena-live-desktop'
    config['version'] = '5.0.0'
    config['private'] = True  # no accidental npm publish; GitHub Releases still works.
    config['main'] = 'desktop/main.cjs'
    config['description'] = 'GREÑA LIVE Desktop — OBS, multichat, voz, alertas y actualizaciones'
    config.setdefault('scripts', {})['desktop'] = 'electron .'
    config['scripts']['dist:win'] = 'electron-builder --win nsis --x64'
    config.setdefault('dependencies', {})['electron-updater'] = '^6.8.9'
    config.setdefault('devDependencies', {})['electron'] = '^44.9.3'
    config['devDependencies']['electron-builder'] = '^26.17.0'
    config['build'] = {
        'appId': 'do.grena.live.desktop', 'productName': 'GREÑA LIVE', 'asar': True,
        'directories': { 'output': 'dist' },
        'files': ['**/*', '!dist/**', '!tests/**', '!.github/**', '!*.md', '!env.example', '!**/*.log', '!**/.gitkeep', '!**/package-lock.json'],
        'win': {'target': ['nsis'], 'icon': 'desktop/icon.ico'},
        'nsis': {'oneClick': False, 'allowToChangeInstallationDirectory': True, 'perMachine': False, 'createDesktopShortcut': True, 'createStartMenuShortcut': True},
        'publish': [{'provider': 'github', 'owner': 'GRENARDD', 'repo': 'GRENALIVE'}]
    }
    return json.dumps(config, indent=2, ensure_ascii=False) + '\n'

PATCHES = {
    'afterglow-overlay.html': patch_overlay,
    'afterglow-studio.html': patch_studio,
    'alerts.html': patch_alerts,
    'assets/alerts-theme-picker.js': patch_picker,
    'server.mjs': patch_server,
    'package.json': patch_package,
}

def main():
    p = argparse.ArgumentParser(description='Aplicar GREÑA Desktop + packs (crea copias de seguridad)')
    p.add_argument('repositorio', type=Path, help='Directorio checkout GRENALIVE')
    p.add_argument('--dry-run', action='store_true')
    args = p.parse_args()
    target = args.repositorio.resolve()
    if not (target/'server.mjs').is_file() or not (target/'afterglow-overlay.html').is_file():
        p.error('La ruta no es un checkout de GREÑA LIVE válido.')
    changed = {}
    for path, patch in PATCHES.items():
        source = (target/path).read_text(encoding='utf-8')
        if 'grena-theme-packs.js?v=1' in source and path.startswith('afterglow'):
            raise RuntimeError('Ya hay una integración instalada. No duplicar. Usa un checkout limpio.')
        changed[path] = patch(source)
    if args.dry_run:
        for path in changed: print('OK:', path)
        return
    backup_dir = target / '.grena-backup-desktop-v5'
    if backup_dir.exists():
        raise RuntimeError('La carpeta de respaldo ya existe. No sobreescribo copias anteriores.')
    backup_dir.mkdir(parents=True)
    for name in changed:
        old = target/name
        (backup_dir/name).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(old, backup_dir/name)
    for name, content in changed.items():
        (target/name).write_text(content, encoding='utf-8')
    for root in ['desktop']:
        shutil.copytree(HERE/root, target/root, dirs_exist_ok=True)
    pack_dir = target/'assets'/'grena-packs'
    for old, new in [('grena-domino-alerts','domino'),('grena-minecraft-alerts-3d','minecraft')]:
        shutil.copytree(HERE/'packs'/old, pack_dir/new, dirs_exist_ok=True)
    shutil.copy2(HERE/'assets-grena-theme-packs.js', target/'assets'/'grena-theme-packs.js')
    shutil.copy2(HERE/'vista-previa-alertas.html', target/'vista-previa-alertas.html')
    workflow_target = target/'.github'/'workflows';workflow_target.mkdir(parents=True,exist_ok=True)
    shutil.copy2(HERE/'.github'/'workflows'/'windows-installer.yml', workflow_target/'windows-installer.yml')
    print('OK: integración aplicada a',target)
    print('Guardado respaldo en',backup_dir)
    print('IMPORTANTE: ejecutar npm install para actualizar package-lock.json, luego npm test.')
    print('GitHub Actions: publicar tag v5.0.0 después de validar la compilación.')

if __name__ == '__main__':
    main()
