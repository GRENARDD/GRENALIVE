'use strict';
// GREÑA Desktop: Shell Electron. Node backend stays in the user's Windows session.
const { app, BrowserWindow, dialog, shell, session } = require('electron');
const { spawn } = require('node:child_process');
const { join } = require('node:path');
const { existsSync } = require('node:fs');
const http = require('node:http');
let mainWindow, backend, checking = false, stopping = false;
const HOST = '127.0.0.1', PORT = 8787, ADDRESS = `http://${HOST}:${PORT}`;
const APP_ROOT = app.getAppPath();
function pause(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function health() {
  return new Promise(resolve => {
    const req = http.get(`${ADDRESS}/health`, { timeout: 1500 }, res => { res.resume(); resolve(res.statusCode === 200); });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(false));
  });
}
async function awaitReady() {
  for (let n = 0; n < 90 && !stopping; n++) {
    if (await health()) return true;
    if (backend?.exitCode !== null && backend?.exitCode !== undefined) break;
    await pause(400);
  }
  return false;
}
function launchBackend() {
  if (!existsSync(join(APP_ROOT, 'server.mjs'))) throw new Error('No se encontró el servidor de GREÑA LIVE.');
  backend = spawn(process.execPath, [join(APP_ROOT, 'server.mjs')], {
    cwd: APP_ROOT,
    windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
    env: {
      ...process.env, ELECTRON_RUN_AS_NODE: '1', GRENA_APP_MODE: '1', GRENA_CLOUD: '0',
      HOST, PORT: String(PORT), GRENA_DATA_DIR: join(app.getPath('appData'), 'GREÑA LIVE PRO'),
    }
  });
  backend.on('error', err => console.error('[GREÑA] backend:', err.message));
  backend.stdout?.on('data', data => console.log('[GREÑA]', String(data).slice(0, 500)));
  backend.stderr?.on('data', data => console.error('[GREÑA]', String(data).slice(0, 500)));
  backend.on('exit', (code, signal) => console.warn('[GREÑA] backend stopped', code, signal));
}
async function stopBackend() {
  if (!backend?.pid) return;
  const p = backend; backend = null;
  if (process.platform === 'win32') {
    await new Promise(resolve => {
      const killer = spawn('taskkill', ['/PID', String(p.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
      killer.on('error', resolve); killer.on('exit', resolve);
      setTimeout(resolve, 3500).unref();
    });
  } else try { p.kill('SIGTERM'); } catch {}
}
function createWindow() {
  mainWindow = new BrowserWindow({
    title: 'GREÑA LIVE', width: 1340, height: 860, minWidth: 950, minHeight: 650,
    autoHideMenuBar: true, backgroundColor: '#0b1018',
    webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, webSecurity: true }
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    // External OAuth pages open in the system browser, not inside GREÑA.
    if (/^https:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    try { if (new URL(url).origin === ADDRESS) return; } catch {}
    event.preventDefault();
    if (/^https:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
  });
  mainWindow.loadURL(ADDRESS).catch(err => console.error('[GREÑA] UI:', err));
  mainWindow.on('closed', () => { mainWindow = null; app.quit(); });
}
function setupPermissions() {
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback, details) => {
    const requestingUrl = details?.requestingUrl || webContents.getURL();
    let local = false;
    try { local = new URL(requestingUrl).origin === ADDRESS; } catch {}
    callback(local && ['media', 'notifications'].includes(permission));
  });
}
async function setupUpdates() {
  if (!app.isPackaged || process.env.GRENA_DISABLE_UPDATES === '1') return;
  let updater;
  try { updater = require('electron-updater').autoUpdater; }
  catch (e) { console.warn('[GREÑA] update integration unavailable:', e.message); return; }
  updater.autoDownload = true;
  updater.autoInstallOnAppQuit = true;
  updater.on('error', e => console.warn('[GREÑA] update:', e.message));
  updater.on('update-available', info => {
    if (mainWindow && !mainWindow.isDestroyed())
      mainWindow.setTitle(`GREÑA LIVE · Descargando versión ${info.version}`);
  });
  updater.on('update-downloaded', async info => {
    if (stopping) return;
    const { response } = await dialog.showMessageBox(mainWindow || undefined, {
      type: 'info', buttons: ['Instalar y reiniciar', 'Más tarde'], defaultId: 0, cancelId: 1,
      title: 'Actualización de GREÑA LIVE',
      message: `La versión ${info.version} ya está descargada.`,
      detail: 'Se conservarán tus perfiles, audios y configuraciones locales. Instala cuando no estés transmitiendo.'
    });
    if (response === 0) { stopping = true; await stopBackend(); updater.quitAndInstall(false, true); }
    else if (mainWindow) mainWindow.setTitle('GREÑA LIVE');
  });
  if (checking) return;
  checking = true;
  try { await updater.checkForUpdates(); } catch (e) { console.warn('[GREÑA] no update check:', e.message); }
  finally { checking = false; }
  // Avoid repeated checks mid-stream; future sessions check again on startup.
}
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', event => {
  if (stopping) return;
  stopping = true;
  event.preventDefault();
  stopBackend().finally(() => app.quit());
});
app.whenReady().then(async () => {
  setupPermissions();
  if (await health()) {
    dialog.showErrorBox('GREÑA LIVE ya está abierto', 'Hay un servicio utilizando el puerto 8787. Cierra la instancia anterior de GREÑA antes de continuar.');
    app.quit(); return;
  }
  try { launchBackend(); }
  catch (e) { dialog.showErrorBox('No se pudo iniciar GREÑA LIVE', e.message); app.quit(); return; }
  if (!(await awaitReady())) {
    dialog.showErrorBox('El motor no inició', 'No se pudo iniciar el servidor local. Revisa las conexiones de Windows y los registros en AppData\\Roaming\\GREÑA LIVE PRO\\logs.');
    app.quit(); return;
  }
  createWindow();
  setupUpdates().catch(e => console.warn('[GREÑA] updates:', e.message));
}).catch(e => { dialog.showErrorBox('GREÑA LIVE', e.message); app.quit(); });
