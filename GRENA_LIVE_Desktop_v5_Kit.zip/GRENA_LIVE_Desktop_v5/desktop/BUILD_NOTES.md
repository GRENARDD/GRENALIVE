# GREÑA LIVE para Windows – distribución y actualizaciones

- Para generar una compilación manual, usa el workflow `GREÑA LIVE - Windows installer` en GitHub Actions. Se adjunta un `Setup.exe` como artefacto.
- Para publicar una versión actualizable, cambia `version` en package.json y crea un tag `vX.Y.Z`, luego publica la Release. `electron-updater` consulta Releases públicas y descarga el instalador NSIS.
- No se necesita Railway para la ejecución local del motor. El equipo debe permanecer encendido durante el LIVE y tener acceso a internet para conectar las plataformas.
- Se preserva `%APPDATA%\\GREÑA LIVE PRO`: perfiles, audios, credenciales por usuario y ajustes nunca van dentro del directorio de instalación.
- EVITA distribuir builds firmados falsamente, deshabilitar Defender o ignorar alertas de antivirus. Sin certificado legítimo Windows SmartScreen puede alertar. Firmar el .exe requiere un certificado.
- Revisar URL de callbacks de OAuth de cada plataforma. Al pasar de Railway a 127.0.0.1, integraciones OAuth que solo acepten el dominio previo podrían fallar hasta configurar redirect URIs o un puente HTTPS seguro.
- La disponibilidad y precio de servicios externos (Fish Audio, auth Cloudflare Worker, APIs de plataformas) son independientes del `.exe`.
- La creación de instaladores por GitHub Actions usa los límites de minutos y almacenamiento de GitHub, aunque para un proyecto pequeño pueden ser gratuitos dentro de la cuota del plan.
- El proyecto necesita `electron`, `electron-builder` y `electron-updater` como dependencias de compilación/ejecución. Un instalador empaqueta GREÑA LIVE y la versión requerida de Electron.
