/* GREÑA LIVE — reusable OBS theme bridge. Original URLs, WS and queues stay in AFTERGLOW. */
const LOAD = Promise.all([
  import('./grena-packs/domino/src/renderer/dominoRenderer.js'),
  import('./grena-packs/domino/src/animations/alerts.js'),
  import('./grena-packs/domino/src/converter/giftConverter.js'),
  import('./grena-packs/domino/src/events/normalizer.js'),
  import('./grena-packs/domino/src/settings/settings.js'),
  import('./grena-packs/minecraft/src/renderer/minecraftRenderer.js'),
  import('./grena-packs/minecraft/src/core/engine.js'),
  import('./grena-packs/minecraft/src/converter/giftConverter.js'),
  import('./grena-packs/minecraft/src/events/normalizer.js'),
  import('./grena-packs/minecraft/src/settings/settings.js')
]);
let deps = null;
const types = { likes: 'like', bits: 'donation', kicks: 'donation' };
const PALETTE = { tiktok: '#ee315f', twitch: '#a970ff', kick: '#4ae145', starvios: '#ff62a4', youtube: '#fe3b3b' };
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, Number(n) || 0));
function rawFromAFTERGLOW(event, data = {}, options = {}) {
  const kind = types[event] || event;
  const platform = String(options.platform || 'tiktok').toLowerCase();
  const result = {
    id: options.raw?.eventId || options.raw?.bridgeEventId || options.raw?.msgId || `${Date.now()}:${kind}:${data.name}`,
    type: kind, platform, user: data.name || 'Alguien', amount: Number(data.amount) || 1,
    viewers: kind === 'raid' ? Number(data.amount) || 1 : undefined,
    gift: kind === 'gift' ? {
      id: String(options.raw?.giftId || data.gift || 'unknown'), name: data.gift || 'Regalo',
      image: data.giftImage || '', animation: options.raw?.giftAnimatedImage || '',
      value: options.raw?.unitDiamonds ?? options.raw?.diamondCount ?? 0,
    } : undefined,
    bits: options.raw?.bits ?? null, value: options.raw?.amountUsd ?? null,
  };
  if (['bits', 'kicks'].includes(event)) {
    result.type = 'gift';
    result.gift = { id: event, name: data.gift || event.toUpperCase(), value: Number(data.amount) || 1 };
  }
  return result;
}
function addCanvas(root, webgl = false) {
  const canvases = [];
  for (let n = 0; n < (webgl ? 2 : 1); n++) {
    const cv = document.createElement('canvas');
    Object.assign(cv.style, { position: 'absolute', inset: '0', display: 'block', width: '100%', height: '100%', pointerEvents: 'none', background: 'transparent' });
    root.appendChild(cv); canvases.push(cv);
  }
  return canvases;
}
function makeSettings(theme, orientation, options) {
  const v = clamp(options.volume ?? 54, 0, 100) / 100;
  const y = orientation === 'vertical' ? (theme === 'domino' ? 0.78 : 0.5) : 0.48;
  return {
    style: theme, volume: options.soundEnabled ? v : 0, mute: !options.soundEnabled,
    size: orientation === 'vertical' ? 0.79 : 0.9, quality: 'high',
    position: { vertical: { x: 0.5, y: orientation === 'vertical' ? y : 0.65 }, horizontal: { x: 0.5, y: 0.48 } },
    effects: { particles: true, shake: true, flash: true }, felt: false,
    giftTiers: { small: 100, medium: 1000 }, customGifts: {},
    events: Object.fromEntries(['follow','sub','gift','like','share','raid','donation'].map(k => [k, { enabled: true, duration: 1, title: ({follow:'¡NUEVO SEGUIDOR!',sub:'¡SUSCRIPCIÓN!',gift:'¡REGALO!',like:'¡TAP TAPS!',share:'¡COMPARTIDO!',raid:'¡RAID!',donation:'¡APOYO!'}[k]) }]))
  };
}
let currentRenderer = null;
let lastRoot = null;
function stopPrevious() {
  try { currentRenderer?.cancel(); } catch {}
  currentRenderer = null;
  if (lastRoot?.isConnected) lastRoot.replaceChildren();
  lastRoot = null;
}
const bridge = {
  ready: false,
  stop: stopPrevious,
  play(theme, event, data, options = {}) {
    if (!deps || !['domino','minecraft3d'].includes(theme)) return null;
    if (theme === 'minecraft3d' && event !== 'gift') return null; // use existing PixelCraft for other event kinds
    const root = options.root;
    if (!(root instanceof HTMLElement)) return null;
    stopPrevious();
    lastRoot = root;
    const orientation = options.layout === 'horizontal' ? 'horizontal' : 'vertical';
    const packTheme = theme === 'minecraft3d' ? 'minecraft' : theme;
    const settings = makeSettings(packTheme, orientation, options);
    const raw = rawFromAFTERGLOW(event, data, options);
    try {
      if (theme === 'domino') {
        const cvs = addCanvas(root);
        const renderer = new deps[0].DominoRenderer(cvs[0], { orientation, getSettings: () => settings });
        currentRenderer = renderer;
        const normalized = deps[3].normalizeEvent(raw);
        const giftConverter = new deps[2].GiftConverter();
        const spec = deps[1].buildAlert(normalized, { conv: giftConverter, settings, lay: renderer.layout() });
        renderer.play(spec).catch?.(err => console.warn('[GREÑA Dominó]', err));
        return { durationMs: Math.max(1800, Math.min(15000, Math.ceil(spec.duration * 1000) + 150)) };
      }
      const cvs = addCanvas(root, true);
      const renderer = new deps[5].MinecraftRenderer(cvs[0], cvs[1], { orientation, getSettings: () => settings });
      currentRenderer = renderer;
      const normalized = deps[8].normalizeEvent(raw);
      const giftConverter = new deps[7].GiftConverter();
      const spec = deps[6].buildChestAlert(normalized, { conv: giftConverter, settings });
      renderer.play(spec).catch?.(err => console.warn('[GREÑA Minecraft 3D]', err));
      return { durationMs: Math.ceil(spec.duration * 1000) + 100 };
    } catch (error) {
      console.warn('[GREÑA packs] Fallback to existing theme:', error);
      stopPrevious();
      return null;
    }
  }
};
window.GrenaThemePacks = bridge;
LOAD.then(items => { deps = items; bridge.ready = true; }).catch(error => console.warn('[GREÑA packs] unavailable:', error));
