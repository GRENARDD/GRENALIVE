from pathlib import Path
import json, ast, subprocess
ROOT=Path(__file__).resolve().parents[1]
assert (ROOT/'desktop'/'main.cjs').is_file()
assert (ROOT/'desktop'/'icon.ico').is_file()
assert (ROOT/'packs'/'grena-domino-alerts'/'src'/'renderer'/'dominoRenderer.js').is_file()
assert (ROOT/'packs'/'grena-minecraft-alerts-3d'/'src'/'renderer'/'minecraftRenderer.js').is_file()
a=(ROOT/'assets-grena-theme-packs.js').read_text()
for e in ('GrenaThemePacks', 'domino', 'minecraft3d', 'buildChestAlert', 'buildAlert', 'soundEnabled'):
 assert e in a,e
b=(ROOT/'tools'/'aplicar_a_grena.py').read_text()
for e in ('patch_overlay', 'patch_server', 'patch_studio', 'patch_alerts', 'patch_picker','patch_package','grena-packs'):
 assert e in b,e
assert 'electron-updater' in (ROOT/'desktop'/'main.cjs').read_text()
for p in [ROOT/'desktop'/'main.cjs', ROOT/'assets-grena-theme-packs.js']:
 assert subprocess.run(['node','--check',str(p)],capture_output=True).returncode==0,str(p)
print('GREÑA v5 kit: integridad estática OK')
