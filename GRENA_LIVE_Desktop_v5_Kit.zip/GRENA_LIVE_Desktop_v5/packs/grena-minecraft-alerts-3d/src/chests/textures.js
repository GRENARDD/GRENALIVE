// Texturas pixeladas 16×16 generadas por código (originales, estilo voxel; NO son archivos de Mojang).
import { rng } from '../utils/hash.js';
export const TILE = { chestSide: 0, chestTop: 1, chestInner: 2, chestFront: 3, chestLidFront: 4, chestMetal: 5, ENDER: 8,
  diaB: 16, diaW: 17, diaL: 18, diaM: 19, diaD: 20, pGold: 24, pWhite: 25, pCyan: 26, pGreen: 27, pPurple: 28, pDust: 29, black: 30 };
export const ATLAS = { tiles: 8, px: 16 };
export function uvRect(i) { const n = ATLAS.tiles, e = 0.4 / (n * ATLAS.px); return [(i % n) / n + e, Math.floor(i / n) / n + e, 1 / n - 2 * e, 1 / n - 2 * e]; }
const hex = (c) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
const shade = (c, k) => '#' + hex(c).map((v) => Math.max(0, Math.min(255, Math.round(v * k))).toString(16).padStart(2, '0')).join('');
function wood(ctx, ox, oy, base, r, { top = false, inner = false, front = false } = {}) {
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    let k = 0.9 + r() * 0.2; if (!inner && y % 5 === 4) k *= 0.72; if (!inner && !top && x % 8 === 0) k *= 0.85;
    if (top && (x === 0 || y === 0 || x === 15 || y === 15)) k *= 0.62; if (front && y === 15) k *= 0.6; if (inner) k *= 0.35;
    ctx.fillStyle = shade(base, k); ctx.fillRect(ox + x, oy + y, 1, 1);
  }
}
export function drawAtlas(ctx) {
  const r = rng(1234), at = (i) => [(i % 8) * 16, Math.floor(i / 8) * 16];
  const pal = { 0: { base: '#8b5a2b', metal: '#bdbdbd' }, 1: { base: '#1d2c33', metal: '#7a4fd0' } };
  for (const v of [0, 1]) {
    const o = v * 8, { base, metal } = pal[v];
    wood(ctx, ...at(o), base, r); wood(ctx, ...at(o + 1), v ? '#26404a' : '#a06a35', r, { top: true }); wood(ctx, ...at(o + 2), base, r, { inner: true });
    wood(ctx, ...at(o + 3), base, r, { front: true }); wood(ctx, ...at(o + 4), base, r, { front: false });
    const [mx, my] = at(o + 5); for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { ctx.fillStyle = shade(metal, (x === 0 || y === 0 || x === 15 || y === 15 ? 0.45 : 0.85) + r() * 0.15); ctx.fillRect(mx + x, my + y, 1, 1); }
    if (v) for (let i = 0; i < 14; i++) { const [tx, ty] = at(o + (i % 4)); ctx.fillStyle = '#35e0c8'; ctx.fillRect(tx + Math.floor(r() * 16), ty + Math.floor(r() * 16), 1, 1); }
  }
  const solid = { 16: '#0a4a55', 17: '#ffffff', 18: '#59f0e0', 19: '#1fb5b0', 20: '#0f7a86', 24: '#ffd23a', 25: '#ffffff', 26: '#4ff0ff', 27: '#3df06a', 28: '#b04dff', 29: '#8a7a68', 30: '#000000' };
  for (const [i, c] of Object.entries(solid)) { const [x, y] = at(+i); ctx.fillStyle = c; ctx.fillRect(x, y, 16, 16); for (let k = 0; k < 10; k++) { ctx.fillStyle = shade(c, 0.88 + r() * 0.2); ctx.fillRect(x + Math.floor(r() * 16), y + Math.floor(r() * 16), 2, 2); } }
}
