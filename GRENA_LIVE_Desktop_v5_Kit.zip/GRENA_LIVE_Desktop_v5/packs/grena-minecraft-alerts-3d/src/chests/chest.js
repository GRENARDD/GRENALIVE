// Cofre articulado (medidas de 16 px por bloque): base 14×10×14, tapa 14×5×14, cerradura 2×4×1. Bisagra en el borde trasero superior.
import { TILE } from './textures.js';
export const RIM = 0.625, HINGE = [0, 0.625, -0.4375];
export function chestParts(variant = 'normal') {
  const o = variant === 'ender' ? TILE.ENDER : 0, [side, top, inner, front, lidFront, metal] = [0, 1, 2, 3, 4, 5].map((i) => i + o);
  return {
    // orden de caras: +x, -x, +y, -y, +z, -z. La cara superior de la base es el interior oscuro.
    base: [{ c: [0, 0.3125, 0], s: [0.875, 0.625, 0.875], t: [side, side, inner, side, front, side] }],
    // la tapa se modela relativa a la bisagra, para rotar sobre ella
    lid: [{ c: [0, 0.15625, 0.4375], s: [0.875, 0.3125, 0.875], t: [side, side, top, side, lidFront, side] },
      { c: [0, 0.0625, 0.90625], s: [0.125, 0.25, 0.0625], t: metal }],
  };
}
