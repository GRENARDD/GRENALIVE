// Partículas voxel (cubos pequeños). Lógica pura; el renderizador las dibuja como cubos.
import { TILE } from '../chests/textures.js';
export const PRESETS = {
  dust: { n: 16, tiles: [TILE.pDust], speed: 2.2, up: 1.2, life: 0.7, size: 0.07, spread: 0.7 },
  gem: { n: 34, tiles: [TILE.pCyan, TILE.pWhite, TILE.diaL], speed: 3.2, up: 3.2, life: 1.0, size: 0.06, spread: 0.3 },
  sparkle: { n: 3, tiles: [TILE.pWhite, TILE.pCyan], speed: 0.8, up: 0.6, life: 0.8, size: 0.045, spread: 1.0 },
  ender: { n: 2, tiles: [TILE.pPurple, TILE.pCyan], speed: 0.5, up: 0.8, life: 1.0, size: 0.05, spread: 0.9 },
};
export class ParticleSystem {
  constructor(max = 400, rand = Math.random) { this.list = []; this.max = max; this.rand = rand; }
  emit(kind, { at = [0, 0, 0], mult = 1, gravity = -9 } = {}) {
    const p = PRESETS[kind], n = Math.round(p.n * mult), r = this.rand;
    for (let i = 0; i < n && this.list.length < this.max; i++) { const a = r() * 6.283;
      this.list.push({ x: at[0] + Math.cos(a) * p.spread * r() * 0.5, y: at[1], z: at[2] + Math.sin(a) * p.spread * r() * 0.5, vx: Math.cos(a) * p.speed * r(), vy: p.up * (0.5 + r()), vz: Math.sin(a) * p.speed * r(),
        age: 0, life: p.life * (0.6 + r() * 0.6), size: p.size * (0.7 + r() * 0.6), tile: p.tiles[Math.floor(r() * p.tiles.length)], g: kind === 'dust' ? gravity : gravity * 0.25, rot: r() * 6 }); }
  }
  update(dt) { for (const q of this.list) { q.age += dt; q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt; q.rot += dt * 4; } this.list = this.list.filter((q) => q.age < q.life); }
  clear() { this.list.length = 0; }
}
