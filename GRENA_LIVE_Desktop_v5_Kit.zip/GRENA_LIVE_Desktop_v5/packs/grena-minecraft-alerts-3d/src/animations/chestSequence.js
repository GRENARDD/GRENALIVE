// Línea de tiempo del cofre (función pura, probada en Node). Unidades locales del cofre: 1 = bloque.
import { RIM } from '../chests/chest.js';
export const T = { fall: 0.75, impact: 0.75, shakeEnd: 1.2, openStart: 1.2, openEnd: 1.8, riseStart: 1.6, riseEnd: 2.6, showEnd: 5.0, sinkEnd: 5.4, closeStart: 5.4, closeEnd: 5.9, end: 6.5 };
export const LID_OPEN = 1.95, GIFT_START_LID = 1.0, GIFT_H = 0.75;
const E = { out: (p) => 1 - Math.pow(1 - p, 3), in: (p) => p * p, io: (p) => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2) };
const c01 = (v) => Math.max(0, Math.min(1, v));
export const EVENTS = [
  { t: T.impact, type: 'thud' }, { t: T.impact, type: 'burst', kind: 'dust' }, { t: T.openStart, type: 'open' }, { t: T.riseStart, type: 'burst', kind: 'gem' },
  { t: T.riseStart + 0.1, type: 'pop' }, { t: T.riseEnd, type: 'levelup' }, { t: T.closeStart, type: 'close' },
];
export function state(t) {
  const c = { y: 0, rotY: 0, sx: 0, sy: 1, scale: 1, alpha: 1, lid: 0 };
  if (t < T.fall) { const p = t / T.fall; c.y = 6 * (1 - E.in(p)); c.rotY = 0.6 * (1 - p); c.alpha = Math.min(1, t / 0.15); }
  else if (t < T.shakeEnd) { const q = t - T.impact; c.sx = Math.sin(q * 60) * 0.04 * Math.exp(-q * 5); c.sy = 1 - 0.1 * Math.exp(-q * 10) * Math.abs(Math.cos(q * 25)); }
  if (t >= T.openStart && t < T.closeStart) c.lid = LID_OPEN * E.out(c01((t - T.openStart) / (T.openEnd - T.openStart)));
  else if (t >= T.closeStart) c.lid = LID_OPEN * (1 - E.io(c01((t - T.closeStart) / (T.closeEnd - T.closeStart))));
  if (t > T.closeEnd) { const p = c01((t - T.closeEnd) / (T.end - T.closeEnd)); c.alpha = 1 - p; c.scale = 1 - 0.3 * p; }
  const g = { visible: false, y: 0.3, s: 0.5, rotY: 0, glow: 0 };
  if (t >= T.riseStart && t < T.sinkEnd) {
    g.visible = true; g.rotY = (t - T.riseStart) * 2.4;
    if (t < T.riseEnd) { const p = E.out(c01((t - T.riseStart) / (T.riseEnd - T.riseStart))); g.y = 0.3 + 1.6 * p; g.s = 0.5 + 0.6 * p; g.glow = p; }
    else if (t < T.showEnd) { g.y = 1.9 + 0.08 * Math.sin((t - T.riseEnd) * 3); g.s = 1.1 + 0.03 * Math.sin((t - T.riseEnd) * 5); g.glow = 1; }
    else { const p = E.in(c01((t - T.showEnd) / (T.sinkEnd - T.showEnd))); g.y = 1.9 - 1.6 * p; g.s = 1.1 * (1 - p); g.glow = 1 - p; }
  }
  return { chest: c, gift: g };
}
export const giftTop = (g) => g.y + (GIFT_H * g.s) / 2;
export { RIM };
