// Sonidos ORIGINALES sintetizados (recreaciones, no muestras del juego). Antisolape por tipo, voces máximas, volumen y mute.
export const COOLDOWN = { open: 400, close: 400, thud: 150, pop: 60, levelup: 500 };
export class Gate { constructor(maxVoices = 8) { this.last = {}; this.voices = []; this.max = maxVoices; }
  allow(type, now) { if (now - (this.last[type] ?? -1e9) < (COOLDOWN[type] ?? 50)) return false; this.voices = this.voices.filter((e) => e > now); if (this.voices.length >= this.max) return false; this.last[type] = now; this.voices.push(now + 600); return true; } }
export class SFX {
  constructor(getCfg) { this.cfg = getCfg; this.ctx = null; this.gate = new Gate(); }
  _c() { if (!this.ctx) { const AC = globalThis.AudioContext || globalThis.webkitAudioContext; if (!AC) return null; this.ctx = new AC(); const n = this.ctx.createBuffer(1, this.ctx.sampleRate * 0.5, this.ctx.sampleRate), d = n.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; this.noise = n; } if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {}); return this.ctx; }
  _g(c, t, v, dur) { const g = c.createGain(); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); g.connect(c.destination); return g; }
  _osc(c, type, t, f0, f1, v, dur, lp) { const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur); let n = o; if (lp) { const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = lp; o.connect(f); n = f; } n.connect(this._g(c, t, v, dur)); o.start(t); o.stop(t + dur); }
  _noise(c, t, v, dur, f, type = 'lowpass') { const s = c.createBufferSource(); s.buffer = this.noise; const b = c.createBiquadFilter(); b.type = type; b.frequency.value = f; s.connect(b); b.connect(this._g(c, t, v, dur)); s.start(t); s.stop(t + dur); }
  play(type) {
    const { volume, mute } = this.cfg(); if (mute || volume <= 0) return; const c = this._c(); if (!c || !this.gate.allow(type, performance.now())) return; const t = c.currentTime, v = volume;
    if (type === 'thud') { this._osc(c, 'sine', t, 140, 40, v, 0.25); this._noise(c, t, v * 0.6, 0.12, 500); }
    else if (type === 'open') { this._osc(c, 'sawtooth', t, 170, 85, v * 0.35, 0.5, 600); this._noise(c, t, v * 0.25, 0.4, 1200, 'bandpass'); this._osc(c, 'square', t + 0.48, 220, 120, v * 0.3, 0.06, 900); }
    else if (type === 'close') { this._osc(c, 'sine', t, 120, 50, v, 0.2); this._noise(c, t, v * 0.5, 0.1, 700); this._osc(c, 'square', t + 0.02, 260, 140, v * 0.3, 0.05, 900); }
    else if (type === 'pop') this._osc(c, 'sine', t, 500, 1100, v * 0.6, 0.09);
    else if (type === 'levelup') [523, 659, 784, 1046].forEach((f, i) => this._osc(c, 'triangle', t + i * 0.09, f, f * 1.003, v * 0.45, 0.22));
  }
}
