// Matrices 4x4 column-major (WebGL). Elemento (fila r, col c) = m[c*4+r].
export const I = () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
export function mul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }
export const T = (x, y, z) => { const m = I(); m[12] = x; m[13] = y; m[14] = z; return m; };
export const S = (x, y = x, z = x) => { const m = I(); m[0] = x; m[5] = y; m[10] = z; return m; };
export const RX = (a) => { const c = Math.cos(a), s = Math.sin(a), m = I(); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; };
export const RY = (a) => { const c = Math.cos(a), s = Math.sin(a), m = I(); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; };
export function perspective(fovy, aspect, n, f) { const t = 1 / Math.tan(fovy / 2), m = new Float32Array(16); m[0] = t / aspect; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = (2 * f * n) / (n - f); return m; }
export function apply(m, [x, y, z]) { const w = m[3] * x + m[7] * y + m[11] * z + m[15]; return [(m[0] * x + m[4] * y + m[8] * z + m[12]) / w, (m[1] * x + m[5] * y + m[9] * z + m[13]) / w, (m[2] * x + m[6] * y + m[10] * z + m[14]) / w]; }
export const CAM = { fov: (35 * Math.PI) / 180, pitch: 0.38, dist: 13, targetY: 1.3 };
/** Vista+proyección. anchor {x,y} en 0..1 de pantalla; size escala el encuadre. */
export function viewProj(aspect, anchor = { x: 0.5, y: 0.5 }, size = 1, cam = CAM) {
  const V = mul(T(0, 0, -cam.dist / size), mul(RX(cam.pitch), T(0, -cam.targetY, 0)));
  const P = mul(T((anchor.x - 0.5) * 2, -(anchor.y - 0.5) * 2, 0), perspective(cam.fov, aspect, 0.1, 100));
  return mul(P, V);
}
