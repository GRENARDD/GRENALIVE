// (Minecraft) Preferencias aisladas por usuario (streamer). Adaptador de almacenamiento inyectable (localStorage, archivo, BD).
import { clamp, clean } from '../utils/hash.js';
const EV = (title) => ({ enabled: true, duration: 1, title });
export const DEFAULTS = {
  style: 'minecraft', // 'original' | 'minecraft' | 'domino'
  volume: 0.8, size: 1, mute: false, quality: 'high',
  position: { horizontal: { x: 0.5, y: 0.5 }, vertical: { x: 0.5, y: 0.55 } },
  effects: { particles: true, shake: true, flash: true },
  giftTiers: { small: 100, medium: 1000 }, customGifts: {},
  events: { follow: EV('¡NUEVO AVENTURERO!'), sub: EV('¡NUEVO GUERRERO DEL TEAM GREÑA!'), gift: EV('¡REGALO RECIBIDO!'), like: EV('¡LLUVIA DE XP!'),
    share: EV('¡COMPARTIÓ LA AVENTURA!'), raid: EV('¡LLEGARON REFUERZOS!'), donation: EV('¡APOYO RECIBIDO!') },
};
const BAD = new Set(['__proto__', 'constructor', 'prototype']);
const merge = (base, p) => {
  const o = { ...base };
  for (const k of Object.keys(p || {})) { if (BAD.has(k)) continue; const v = p[k]; o[k] = (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object') ? merge(base[k], v) : v; }
  return o;
};
export const memoryStorage = () => { const m = new Map(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, v) }; };
export class SettingsStore {
  constructor(storage = memoryStorage(), prefix = 'grena-domino:') { this.s = storage; this.prefix = prefix; this.cache = new Map(); }
  _id(u) { return /^[\w.@-]{1,64}$/.test(u) ? u : 'default'; }
  get(userId = 'default') {
    const id = this._id(userId); if (this.cache.has(id)) return this.cache.get(id);
    let saved = {}; try { saved = JSON.parse(this.s.getItem(this.prefix + id) || '{}'); } catch { /* datos corruptos: defaults */ }
    const v = this._fix(merge(DEFAULTS, saved)); this.cache.set(id, v); return v;
  }
  set(userId, patch) { const id = this._id(userId); const v = this._fix(merge(this.get(id), patch)); this.cache.set(id, v); try { this.s.setItem(this.prefix + id, JSON.stringify(v)); } catch { /* cuota llena */ } return v; }
  _fix(v) {
    v.volume = clamp(+v.volume || 0, 0, 1); v.size = clamp(+v.size || 1, 0.3, 2.5);
    if (!['original', 'minecraft', 'domino'].includes(v.style)) v.style = 'minecraft';
    if (!['low', 'medium', 'high'].includes(v.quality)) v.quality = 'high'; v.mute = !!v.mute;
    for (const o of ['horizontal', 'vertical']) { v.position[o].x = clamp(+v.position[o].x, 0, 1); v.position[o].y = clamp(+v.position[o].y, 0, 1); }
    for (const e of Object.values(v.events)) { e.title = clean(e.title, 60); e.duration = clamp(+e.duration || 1, 0.5, 3); e.enabled = !!e.enabled; }
    return v;
  }
  /** Persistencia por usuario: contador de eventos por espectador (para futuras personalizaciones). */
  record(userId, ev) { const id = this._id(userId); const k = `${this.prefix}stats:${id}`; let st = {}; try { st = JSON.parse(this.s.getItem(k) || '{}'); } catch { st = {}; }
    const n = clean(ev.user, 40); if (BAD.has(n)) return; st[n] = (st[n] || 0) + 1; const keys = Object.keys(st); if (keys.length > 2000) delete st[keys[0]];
    try { this.s.setItem(k, JSON.stringify(st)); } catch { /* ignorar */ } }
}
