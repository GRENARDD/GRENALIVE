// Modelos voxel ORIGINALES (sprite extruido). Diamante: forma de gema propia en tonos cian; no copia el sprite de Mojang.
import { TILE } from '../chests/textures.js';
const DIAMOND = ['...BBBBBBBB...', '..BWWLLLLLMMB.', '.BWWLLLLLLLMMB', 'BBBBBBBBBBBBBB', '.BWLLLLLLLLMDB', '..BWLLLLLLMDB.', '...BLLLLLMDB..', '....BLLLMDB...', '.....BLLMDB...', '......BLMDB...', '.......BDB....', '........B.....'];
const PAL = { B: TILE.diaB, W: TILE.diaW, L: TILE.diaL, M: TILE.diaM, D: TILE.diaD };
function extrude(rows, depth = 2) {
  const px = 1 / 16, h = rows.length, w = rows[0].length, boxes = [];
  rows.forEach((row, y) => [...row].forEach((ch, x) => { if (PAL[ch]) boxes.push({ c: [(x - w / 2 + 0.5) * px, (h / 2 - y - 0.5) * px, 0], s: [px, px, depth * px], t: PAL[ch] }); }));
  return boxes;
}
export const MODELS = { diamond: { boxes: extrude(DIAMOND), height: 12 / 16, label: 'Diamante' } };
export const modelFor = (id) => MODELS[id] || null;
