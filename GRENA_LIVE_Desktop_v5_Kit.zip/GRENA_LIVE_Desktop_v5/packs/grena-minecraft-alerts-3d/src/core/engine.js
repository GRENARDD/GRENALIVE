// Fachada Minecraft: normalizador → cola → ajustes → alerta de cofre. Fase 1: solo REGALOS con cofre + diamante.
import { normalizeEvent } from '../events/normalizer.js';
import { AlertQueue } from './queue.js';
import { GiftConverter } from '../converter/giftConverter.js';
import { SettingsStore } from '../settings/settings.js';
import { T } from '../animations/chestSequence.js';
import { MODELS } from '../gifts/models.js';
const PL = { tiktok: 'TikTok', twitch: 'Twitch', kick: 'Kick', starvios: 'Starvios' };
/** Evento normalizado → spec de alerta. Cofre: ender para nivel alto, normal en el resto (cofre doble/encantado/legendario: pendiente). */
export function buildChestAlert(ev, { conv, settings }) {
  const g = conv.convert(ev.gift, ev.amount, ev.platform, settings.giftTiers), cfg = settings.events.gift;
  const model = g.custom?.model || 'diamond'; // sin modelo asignado se usa el diamante como PROVISIONAL (no es el objeto real del regalo)
  return { type: 'gift', variant: g.tier === 'large' ? 'ender' : 'normal', model, tier: g.tier, duration: T.end * (cfg.duration || 1), title: cfg.title,
    lines: [`${ev.user} envió ${g.name}${ev.amount > 1 ? ' ×' + ev.amount : ''}`, PL[ev.platform] || (ev.platform !== 'unknown' ? ev.platform : '')], meta: { placeholder: !MODELS[model] || !g.custom?.model, giftKey: g.key } };
}
export class MinecraftAlerts {
  constructor({ renderer = null, settings = new SettingsStore(), userId = 'default', converter, onDelegate, onError = (e) => console.error('[minecraft]', e) } = {}) {
    Object.assign(this, { renderer, settings, userId, onDelegate, onError, lastSpec: null });
    this.converter = converter || new GiftConverter({ custom: settings.get(userId).customGifts });
    this.queue = new AlertQueue({ play: (ev) => this._play(ev), onError });
  }
  push(raw) { let ev; try { ev = normalizeEvent(raw); } catch (e) { this.onError(e); return 'invalid'; } return this.queue.push(ev); }
  async _play(ev) {
    const st = this.settings.get(this.userId);
    if (st.style !== 'minecraft') { this.onDelegate?.(ev, st.style); return; }
    if (ev.type !== 'gift') { this.onDelegate?.(ev, 'pending'); return; }      // Fases 2 y 4: aún sin implementar → se devuelve a GREÑA LIVE, no se pierde
    if (!st.events.gift.enabled) return;
    const spec = buildChestAlert(ev, { conv: this.converter, settings: st }); this.lastSpec = spec; this.settings.record(this.userId, ev);
    if (this.renderer) await this.renderer.play(spec);
  }
}
