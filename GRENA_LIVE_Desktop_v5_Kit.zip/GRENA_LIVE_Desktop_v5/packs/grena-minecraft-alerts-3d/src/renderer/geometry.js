// Geometría de cajas fusionadas (pura; probada en Node). Vértice: pos(3) normal(3) uv(2). Cara hacia afuera en sentido antihorario.
import { uvRect } from '../chests/textures.js';
export const FACES = [
  { n: [1, 0, 0], v: [[1, -1, -1], [1, 1, -1], [1, 1, 1], [1, -1, 1]], uv: [[0, 1], [0, 0], [1, 0], [1, 1]] },
  { n: [-1, 0, 0], v: [[-1, -1, 1], [-1, 1, 1], [-1, 1, -1], [-1, -1, -1]], uv: [[0, 1], [0, 0], [1, 0], [1, 1]] },
  { n: [0, 1, 0], v: [[-1, 1, -1], [-1, 1, 1], [1, 1, 1], [1, 1, -1]], uv: [[0, 0], [0, 1], [1, 1], [1, 0]] },
  { n: [0, -1, 0], v: [[-1, -1, 1], [-1, -1, -1], [1, -1, -1], [1, -1, 1]], uv: [[0, 0], [0, 1], [1, 1], [1, 0]] },
  { n: [0, 0, 1], v: [[-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], uv: [[0, 1], [1, 1], [1, 0], [0, 0]] },
  { n: [0, 0, -1], v: [[1, -1, -1], [-1, -1, -1], [-1, 1, -1], [1, 1, -1]], uv: [[0, 1], [1, 1], [1, 0], [0, 0]] },
];
/** boxes: [{c:[x,y,z], s:[w,h,d], t: tile | [6 tiles] | null(uv 0..1)}] */
export function mergeBoxes(boxes) {
  const pos = [], idx = []; let base = 0;
  for (const b of boxes) FACES.forEach((f, fi) => {
    const tile = Array.isArray(b.t) ? b.t[fi] : b.t, r = tile == null ? [0, 0, 1, 1] : uvRect(tile);
    f.v.forEach((v, k) => pos.push(b.c[0] + (v[0] * b.s[0]) / 2, b.c[1] + (v[1] * b.s[1]) / 2, b.c[2] + (v[2] * b.s[2]) / 2, f.n[0], f.n[1], f.n[2], r[0] + f.uv[k][0] * r[2], r[1] + f.uv[k][1] * r[3]));
    idx.push(base, base + 1, base + 2, base, base + 2, base + 3); base += 4;
  });
  return { vertices: new Float32Array(pos), indices: new Uint16Array(idx) };
}
