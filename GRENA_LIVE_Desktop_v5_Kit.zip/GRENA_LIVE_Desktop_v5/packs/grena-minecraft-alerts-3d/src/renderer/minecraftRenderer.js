// Renderizador WebGL propio (sin dependencias) con canvas transparente + canvas 2D de texto pixelado.
import { mul, T, S, RX, RY, viewProj } from '../utils/mat4.js';
import { mergeBoxes } from './geometry.js';
import { drawAtlas, uvRect, ATLAS, TILE } from '../chests/textures.js';
import { chestParts, HINGE } from '../chests/chest.js';
import { modelFor } from '../gifts/models.js';
import { state, EVENTS, T as TL } from '../animations/chestSequence.js';
import { ParticleSystem } from '../particles/particles.js';
import { SFX } from '../audio/sfx.js';
const VS = `attribute vec3 p;attribute vec3 n;attribute vec2 uv;uniform mat4 uVP,uM;uniform vec4 uR;varying vec2 vUv;varying vec3 vN;
void main(){vUv=uR.xy+uv*uR.zw;vN=mat3(uM)*n;gl_Position=uVP*uM*vec4(p,1.);}`;
const FS = `precision mediump float;uniform sampler2D uTex;uniform float uA,uGlow;varying vec2 vUv;varying vec3 vN;
void main(){vec4 t=texture2D(uTex,vUv);float l=.55+.45*max(dot(normalize(vN),normalize(vec3(.4,.9,.5))),0.);vec3 c=t.rgb*l+t.rgb*uGlow*.6;float a=t.a*uA;gl_FragColor=vec4(c*a,a);}`;
const K = 2.0; // escala mundo: 1 bloque local = K unidades
const QUALITY = { low: 0.35, medium: 0.7, high: 1.2 };
export class MinecraftRenderer {
  constructor(glCanvas, textCanvas, { getSettings, orientation = 'horizontal' }) {
    this.cv = glCanvas; this.tx = textCanvas.getContext('2d'); this.textCanvas = textCanvas; this.getSettings = getSettings;
    const gl = (this.gl = glCanvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false }));
    if (!gl) throw new Error('WebGL no disponible');
    this.fps = 0; this.parts = new ParticleSystem(); this.sfx = new SFX(() => this.getSettings()); this._loop = this._loop.bind(this);
    glCanvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.cancel(); });
    glCanvas.addEventListener('webglcontextrestored', () => this._init());
    this._init(); this.setOrientation(orientation);
  }
  _init() {
    const gl = this.gl, sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
    const pr = (this.prog = gl.createProgram()); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
    this.loc = Object.fromEntries(['uVP', 'uM', 'uR', 'uTex', 'uA', 'uGlow'].map((n) => [n, gl.getUniformLocation(pr, n)])); this.att = ['p', 'n', 'uv'].map((n) => gl.getAttribLocation(pr, n));
    const ac = document.createElement('canvas'); ac.width = ac.height = ATLAS.tiles * ATLAS.px; drawAtlas(ac.getContext('2d'));
    this.tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, ac);
    for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.NEAREST], [gl.TEXTURE_MAG_FILTER, gl.NEAREST], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
    this.meshes = new Map(); this.cube = this._mesh('cube', [{ c: [0, 0, 0], s: [1, 1, 1], t: null }]);
  }
  _mesh(key, boxes) {
    if (this.meshes.has(key)) return this.meshes.get(key); const gl = this.gl, g = mergeBoxes(boxes), vb = gl.createBuffer(), ib = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, g.vertices, gl.STATIC_DRAW); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, g.indices, gl.STATIC_DRAW);
    const m = { vb, ib, n: g.indices.length }; this.meshes.set(key, m); return m;
  }
  _draw(m, model, vp, { alpha = 1, glow = 0, rect = [0, 0, 1, 1] } = {}) {
    const gl = this.gl; gl.bindBuffer(gl.ARRAY_BUFFER, m.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.ib);
    [[0, 3, 0], [1, 3, 12], [2, 2, 24]].forEach(([i, s, o]) => { gl.enableVertexAttribArray(this.att[i]); gl.vertexAttribPointer(this.att[i], s, gl.FLOAT, false, 32, o); });
    gl.uniformMatrix4fv(this.loc.uVP, false, vp); gl.uniformMatrix4fv(this.loc.uM, false, model); gl.uniform4fv(this.loc.uR, rect); gl.uniform1f(this.loc.uA, alpha); gl.uniform1f(this.loc.uGlow, glow); gl.drawElements(gl.TRIANGLES, m.n, gl.UNSIGNED_SHORT, 0);
  }
  setOrientation(o) { this.orientation = o; const W = o === 'vertical' ? 1080 : 1920, H = o === 'vertical' ? 1920 : 1080; this.W = W; this.H = H; for (const c of [this.cv, this.textCanvas]) { c.width = W; c.height = H; } }
  layout() { return { W: this.W, H: this.H }; }
  cancel() { cancelAnimationFrame(this.raf); this.raf = 0; this.parts.clear(); this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT); this.tx.clearRect(0, 0, this.W, this.H); this._res?.(); this._res = null; this.spec = null; }
  play(spec) { return new Promise((res) => { this.cancel(); this._res = res; this.spec = spec; this.t0 = performance.now(); this.last = this.t0; this.ev = 0; this.raf = requestAnimationFrame(this._loop); }); }
  _loop(now) {
    const s = this.spec; if (!s) return; const k = s.speed || 1, t = ((now - this.t0) / 1000) * (1 / (s.duration / TL.end)) , dt = Math.min(0.05, (now - this.last) / 1000); this.last = now;
    this.fps += (1 / Math.max(dt, 0.001) - this.fps) * 0.05; this._frame(t, dt * (TL.end / s.duration));
    if (t >= TL.end) { this.raf = 0; this.gl.clear(this.gl.COLOR_BUFFER_BIT); this.tx.clearRect(0, 0, this.W, this.H); this.spec = null; const r = this._res; this._res = null; r?.(); return; }
    this.raf = requestAnimationFrame(this._loop);
  }
  _frame(t, dt) {
    const gl = this.gl, st = this.getSettings(), s = this.spec, q = QUALITY[st.quality] ?? 1, pos = st.position[this.orientation], ender = s.variant === 'ender', model = modelFor(s.model);
    const ST = state(t), C = ST.chest, G = ST.gift; const at = (y) => [0, y * 1, 0];
    while (this.ev < EVENTS.length && EVENTS[this.ev].t <= t) { const e = EVENTS[this.ev++]; if (e.type === 'burst') this.parts.emit(e.kind, { mult: q }); else this.sfx.play(e.type); }
    if (G.visible && t < TL.showEnd) this.parts.emit('sparkle', { at: [0, G.y, 0], mult: q * dt * 20 });
    if (ender && t > TL.openStart && t < TL.closeStart) this.parts.emit('ender', { at: [0, 0.65, 0], mult: q * dt * 40 });
    this.parts.update(dt);
    gl.viewport(0, 0, this.W, this.H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.useProgram(this.prog); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.uniform1i(this.loc.uTex, 0);
    const vp = viewProj(this.W / this.H, pos, st.size), parts = chestParts(s.variant), A = C.alpha;
    const base = this._mesh('base:' + s.variant, parts.base), lid = this._mesh('lid:' + s.variant, parts.lid);
    const sq = Math.max(0.2, 1 / Math.max(0.5, C.sy));  // al aplastar en Y, ensancha un poco
    const Gm = mul(T(C.sx * K, C.y * K, 0), mul(RY(C.rotY), S(K * C.scale * sq, K * C.scale * C.sy, K * C.scale * sq)));
    // sombra en el suelo (se desvanece con la altura)
    this._draw(this._mesh('cube', [{ c: [0, 0, 0], s: [1, 1, 1], t: null }]), mul(T(0, 0.005, 0), S(K * 1.25, 0.01, K * 1.25)), vp, { alpha: 0.35 * A * Math.max(0, 1 - C.y / 7), rect: uvRect(TILE.black) });
    this._draw(base, Gm, vp, { alpha: A });
    this._draw(lid, mul(Gm, mul(T(...HINGE), RX(-C.lid))), vp, { alpha: A });
    if (G.visible && model) this._draw(this._mesh('m:' + s.model, model.boxes), mul(Gm, mul(T(0, G.y, 0), mul(RY(G.rotY), S(G.s)))), vp, { alpha: A, glow: G.glow * (0.6 + 0.4 * Math.sin(t * 6)) });
    for (const p of this.parts.list) this._draw(this.cube, mul(T(p.x * K, (p.y + C.y) * K, p.z * K), mul(RY(p.rot), S(p.size * K))), vp, { alpha: Math.min(1, (1 - p.age / p.life) * 2) * A, glow: 0.8, rect: uvRect(p.tile) });
    this._text(t, s, pos);
  }
  _text(t, s, pos) {
    const c = this.tx, W = this.W, H = this.H; c.clearRect(0, 0, W, H); const fade = Math.max(0, Math.min(1, (TL.closeEnd - t) / 0.6)); if (fade <= 0) return;
    const cx = W * pos.x, y0 = H * (pos.y + 0.235);
    [[s.title, 2.0, 0, 76, '#ffe066'], [s.lines[0], 2.3, 1, 44, '#ffffff'], [s.lines[1], 2.5, 2, 30, '#b8b8b8']].forEach(([text, at, i, px, col]) => {
      if (!text || t < at) return; const a = Math.min(1, (t - at) / 0.25) * fade, tmp = this._tmp || (this._tmp = document.createElement('canvas')), t2 = tmp.getContext('2d'), f = px / 4;
      t2.font = `bold ${f}px "Courier New",monospace`; let w = Math.ceil(t2.measureText(text).width) + 2; const maxW = (W * 0.96) / 4; let ff = f; if (w > maxW) { ff = f * (maxW / w); w = Math.ceil(maxW); }
      tmp.width = w; tmp.height = Math.ceil(f * 1.5) + 2; t2.font = `bold ${ff}px "Courier New",monospace`; t2.textBaseline = 'top'; t2.fillStyle = '#1a1a1a'; t2.fillText(text, 1, 1); t2.fillStyle = col; t2.fillText(text, 0, 0);
      c.save(); c.globalAlpha = a; c.imageSmoothingEnabled = false; const yy = y0 + [0, 130, 200][i]; c.drawImage(tmp, cx - (tmp.width * 4) / 2, yy, tmp.width * 4, tmp.height * 4); c.restore();
    });
  }
}
