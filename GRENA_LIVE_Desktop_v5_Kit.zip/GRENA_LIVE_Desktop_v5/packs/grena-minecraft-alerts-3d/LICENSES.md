# Licencias y recursos

- **Código**: original de este proyecto, sin dependencias en el navegador (WebGL propio, sin Three.js). Servidor: `ws` (MIT) vía npm.
- **Texturas** (`src/chests/textures.js`): generadas por código, 16×16 pixeladas, estilo voxel. **No son archivos de Mojang/Microsoft.**
- **Modelos** (cofre, diamante): originales, construidos con cubos. No son modelos oficiales de Minecraft ni se presentan como tales. «Minecraft» es marca de Mojang AB; este proyecto no está afiliado ni respaldado por Mojang/Microsoft.
- **Sonidos**: recreaciones originales sintetizadas con WebAudio. No son muestras del juego.
- **Fuentes**: `Courier New`/monospace del sistema, reescalada sin suavizado para efecto pixelado.
- **Imágenes de regalos**: provienen de las plataformas vía GREÑA LIVE; rigen sus términos.
