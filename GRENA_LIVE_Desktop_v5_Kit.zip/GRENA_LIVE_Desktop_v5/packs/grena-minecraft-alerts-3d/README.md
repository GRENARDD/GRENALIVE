# GREÑA Minecraft Alerts 3D — Fase 1

Cofre voxel 3D (WebGL propio) que cae, vibra, abre la tapa articulada y libera un diamante con partículas, sonido y texto. Fondo transparente, horizontal 1920×1080 y vertical 1080×1920.

```
npm install && npm start     # http://localhost:3000  (simulador)
npm test                     # 10 pruebas
```
OBS: `overlay.html?user=ID&orientation=horizontal|vertical`.

## Estado real por fase
| Fase | Estado |
|---|---|
| 1. Cofre → diamante, partículas, sonido, texto | **Implementada. Lógica probada en Node; visual/audio SIN ver ni oír** (no había navegador) |
| 2. Seguidor, suscripción, regalo premium | Pendiente (solo el regalo con cofre Ender para nivel alto) |
| 3. Catálogo real y mapeos por regalo | **No hecha**: no tengo acceso al repositorio ni al catálogo real de GREÑA LIVE; no invento IDs |
| 4. Likes, compartir, raids, donaciones | Pendiente (se devuelven a GREÑA LIVE con `onDelegate(ev,'pending')`) |
| 5. Selector y fuente OBS existente | Parcial: el selector existe en el motor (`style`) y delega Original/Dominó; falta integrarlo en la app real |
| 6. Pruebas visuales, OBS, eventos reales | Pendiente |

## Qué se verificó por código
Caras 3D hacia afuera; UV dentro del atlas; cámara (arriba/abajo y encuadre en ambas orientaciones); la tapa sube y se echa atrás; **el regalo nunca supera el borde del cofre mientras la tapa no esté abierta**; fotogramas de sonido; partículas; antisolape de audio; motor y delegación.

## Pendiente o limitado (honesto)
- Sin Three.js (no hay red aquí): renderizador WebGL propio y pequeño. Sin sombras reales (solo sombra plana), sin cámara cinematográfica.
- Solo cofre normal y Ender (tinte y partículas moradas). Faltan doble, encantado y legendario.
- Solo modelo de diamante. Regalos sin modelo muestran el diamante como **provisional** (`meta.placeholder`), con el nombre real en el texto. El marco con imagen original aún no está.
- Sin mobs, mesas, TNT, dragón, etc. (`src/mobs/` vacío).
- Los umbrales 100/1000 son marcadores: deben ajustarse con valores reales por plataforma.
- No se hace «conversión 3D de cualquier imagen 2D».
