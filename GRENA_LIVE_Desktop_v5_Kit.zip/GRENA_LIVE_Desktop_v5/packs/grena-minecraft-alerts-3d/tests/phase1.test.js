import test from 'node:test'; import assert from 'node:assert/strict';
import { mergeBoxes, FACES } from '../src/renderer/geometry.js';
import { viewProj, apply, mul, T as Tm, RX } from '../src/utils/mat4.js';
import { state, T, EVENTS, giftTop, GIFT_START_LID, LID_OPEN } from '../src/animations/chestSequence.js';
import { RIM, chestParts, HINGE } from '../src/chests/chest.js';
import { MODELS } from '../src/gifts/models.js';
import { ParticleSystem } from '../src/particles/particles.js';
import { Gate } from '../src/audio/sfx.js';
import { MinecraftAlerts, buildChestAlert } from '../src/core/engine.js';
import { SettingsStore } from '../src/settings/settings.js';
import { GiftConverter } from '../src/converter/giftConverter.js';
import { uvRect } from '../src/chests/textures.js';
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
test('geometría: todas las caras miran hacia afuera (sentido antihorario)', () => {
  for (const f of FACES) { const [a, b, c] = f.v, e1 = b.map((v, i) => v - a[i]), e2 = c.map((v, i) => v - b[i]), n = cross(e1, e2); assert.ok(n.every((v, i) => Math.sign(v) === f.n[i]), JSON.stringify(f.n)); }
  const g = mergeBoxes([{ c: [0, 0, 0], s: [1, 1, 1], t: 0 }]); assert.equal(g.vertices.length, 24 * 8); assert.equal(g.indices.length, 36);
});
test('UV: cada tile queda dentro del atlas', () => { for (let i = 0; i < 31; i++) { const [u, v, w, h] = uvRect(i); assert.ok(u >= 0 && v >= 0 && u + w <= 1 && v + h <= 1); } });
test('cámara: mirar desde arriba (alto→arriba en pantalla, cerca→abajo) y todo el encuadre visible en ambas orientaciones', () => {
  for (const [asp, n] of [[1920 / 1080, 'h'], [1080 / 1920, 'v']]) {
    const m = viewProj(asp), p0 = apply(m, [0, 0, 0]), pUp = apply(m, [0, 1, 0]), near = apply(m, [0, 0, 1]), far = apply(m, [0, 0, -1]);
    assert.ok(pUp[1] > p0[1], n); assert.ok(near[1] < far[1], n);
    for (const pt of [[0, 4.8, 0], [1.25, 0, 1.25], [-1.25, 0, 1.25], [0, 0, 1.25], [0.9, 4.4, 0.9]]) { const [x, y] = apply(m, pt); assert.ok(Math.abs(x) < 1 && Math.abs(y) < 1, `${n} ${pt}`); }
  }
});
test('tapa: al abrir, el borde frontal sube y se echa hacia atrás (no atraviesa la base)', () => {
  const front = (ang) => apply(mul(Tm(...HINGE), RX(-ang)), [0, 0, 0.875]);
  assert.ok(front(0)[1] - HINGE[1] < 1e-9); assert.ok(front(1.0)[1] > RIM); assert.ok(front(LID_OPEN)[2] < 0.875 && front(LID_OPEN)[1] > RIM + 0.5);
});
test('secuencia: el regalo nunca atraviesa la tapa cerrada', () => {
  let shown = 0;
  for (let t = 0; t <= T.end; t += 0.005) { const { chest, gift } = state(t);
    if (gift.visible) { shown++; if (giftTop(gift) > RIM + 1e-6) assert.ok(chest.lid >= GIFT_START_LID, `t=${t}`); }
    assert.ok(chest.lid >= -1e-9 && chest.lid <= LID_OPEN + 1e-9); assert.ok(chest.alpha >= 0 && chest.alpha <= 1); }
  assert.ok(shown > 100); assert.equal(state(T.end).chest.alpha, 0); assert.equal(state(T.sinkEnd + 0.01).gift.visible, false); assert.ok(state(T.end).chest.lid < 1e-6);
  assert.ok(state(T.impact).chest.y < 1e-6); assert.ok(state(0.01).chest.y > 5);
});
test('secuencia: eventos de sonido ordenados y dentro de la duración; cada sonido tiene su fotograma', () => {
  for (let i = 1; i < EVENTS.length; i++) assert.ok(EVENTS[i].t >= EVENTS[i - 1].t); assert.ok(EVENTS.every((e) => e.t >= 0 && e.t < T.end));
  assert.equal(EVENTS.find((e) => e.type === 'thud').t, T.impact); assert.equal(EVENTS.find((e) => e.type === 'open').t, T.openStart); assert.equal(EVENTS.find((e) => e.type === 'close').t, T.closeStart);
});
test('modelos: cofre con tapa y cerradura articuladas; diamante voxel no vacío', () => {
  const p = chestParts(); assert.equal(p.base.length, 1); assert.equal(p.lid.length, 2); assert.equal(chestParts('ender').base[0].t[0], 8);
  assert.ok(MODELS.diamond.boxes.length > 60); assert.ok(MODELS.diamond.boxes.every((b) => b.c.every(Number.isFinite)));
});
test('partículas: límite, caducidad y reproducibilidad', () => {
  const ps = new ParticleSystem(50, () => 0.5); ps.emit('gem', { mult: 10 }); assert.equal(ps.list.length, 50); for (let i = 0; i < 400; i++) ps.update(0.01); assert.equal(ps.list.length, 0);
});
test('audio: antisolape por tipo y límite de voces', () => {
  const g = new Gate(2); assert.ok(g.allow('pop', 0)); assert.equal(g.allow('pop', 10), false); assert.ok(g.allow('thud', 10)); assert.equal(g.allow('open', 20), false); assert.ok(g.allow('pop', 5000));
});
test('motor: regalo → cofre; nivel alto → Ender; regalo desconocido NO se pierde y marca provisional; otros eventos y otros estilos se devuelven', async () => {
  const s = new SettingsStore(); const out = []; const eng = new MinecraftAlerts({ settings: s, userId: 'u', onDelegate: (e, st) => out.push([e.type, st]) });
  eng.push({ id: '1', type: 'gift', platform: 'tiktok', user: 'Ana', amount: 3, gift: { id: 'rose', name: 'Rosa', value: 1 } }); await new Promise((r) => setTimeout(r, 10));
  assert.equal(eng.lastSpec.variant, 'normal'); assert.ok(eng.lastSpec.lines[0].includes('Rosa ×3')); assert.equal(eng.lastSpec.meta.placeholder, true);
  eng.push({ id: '2', type: 'gift', platform: 'kick', user: 'B', gift: { id: 'x', value: 99999 } }); await new Promise((r) => setTimeout(r, 10)); assert.equal(eng.lastSpec.variant, 'ender');
  eng.push({ id: '3', type: 'follow', user: 'a' }); await new Promise((r) => setTimeout(r, 10)); assert.deepEqual(out.at(-1), ['follow', 'pending']);
  s.set('u', { style: 'domino' }); eng.push({ id: '4', type: 'gift', user: 'a', gift: { id: 'q' } }); await new Promise((r) => setTimeout(r, 10)); assert.deepEqual(out.at(-1), ['gift', 'domino']);
});
