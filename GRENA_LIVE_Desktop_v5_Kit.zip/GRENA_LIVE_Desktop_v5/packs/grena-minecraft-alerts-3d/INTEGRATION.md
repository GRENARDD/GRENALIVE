# Integración (Fase 1)

No modifica GREÑA LIVE; no inspeccioné su repositorio (no disponible aquí).

- **Motor**: `new MinecraftAlerts({renderer, settings, userId, onDelegate}).push(rawEvent)`. Flujo: normalizador → cola (prioridad, duplicados, combos) → ajustes → `buildChestAlert` → `MinecraftRenderer`. Misma cola/normalizador/conversor que el módulo Dominó.
- **Selector Original | Minecraft | Dominó**: `settings.style`. Si no es `minecraft`, el motor no dibuja y llama `onDelegate(evento, estilo)`; eventos aún no implementados llegan como `onDelegate(evento,'pending')`. Para conservar URL, token y fuentes de OBS, GREÑA LIVE debe cargar el módulo del estilo elegido dentro de la **misma** página/fuente y enrutar `grena:delegate`. Eso está sin integrar.
- **WebSocket/HTTP** (`src/server.js`): canal por `?user=`, ingesta `POST /event?user=&token=` o WS con token (`GRENA_TOKEN`). Servidor de desarrollo: en producción GREÑA LIVE debe usar su propio servidor, no este.
- **OBS**: Fuente de navegador transparente; 1920×1080 u 1080×1920 con `x`,`y`,`size`,`volume`.
- **Persistencia**: `SettingsStore(storage)` inyectable (usa tu BD/Railway); hoy `localStorage`/memoria.
- **Regalos**: `GiftConverter` (nivel por valor×cantidad, `setCustom('plataforma:id',{tier,name,model})`, caché). El catálogo real y mapeos individuales: pendiente (Fase 3).
