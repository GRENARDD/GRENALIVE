# Licencias y recursos

- **Código**: original de este proyecto. Sin dependencias en el navegador. Servidor: `ws` (MIT) vía npm.
- **Fichas, mesa, partículas, texto**: dibujados por código (Canvas 2D). No hay imágenes ni modelos de terceros.
- **Sonidos**: sintetizados con WebAudio; no son grabaciones reales. Si colocas `click.ogg` y `slam.ogg` en `public/assets/sounds/`, se usan automáticamente. Usa solo grabaciones propias o con licencia (CC0/comercial) y anótalas aquí.
- **Fuentes**: pila del sistema (`Arial Black`, `Impact`, `Arial`). `public/assets/fonts/` queda vacío; si añades una fuente, registra su licencia aquí.
- **Imágenes/animaciones de regalos**: provienen de las plataformas a través de GREÑA LIVE; su uso se rige por los términos de cada plataforma. El módulo solo las muestra.
