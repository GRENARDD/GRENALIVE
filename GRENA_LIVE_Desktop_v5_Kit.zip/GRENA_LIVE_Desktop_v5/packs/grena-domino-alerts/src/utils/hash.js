export const hash = (s) => { let h = 2166136261; for (const c of String(s)) { h ^= c.codePointAt(0); h = Math.imul(h, 16777619); } return h >>> 0; };
export const rng = (seed) => { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const clean = (s, n = 40) => String(s ?? '').replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, n);
export const safeUrl = (u) => (typeof u === 'string' && u.length < 500000 && /^(https?:\/\/|data:image\/(png|jpeg|webp|gif);base64,)/i.test(u)) ? u : null;
