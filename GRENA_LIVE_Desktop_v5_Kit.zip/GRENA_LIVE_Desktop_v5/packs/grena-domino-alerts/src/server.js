// Servidor autónomo: estáticos + WebSocket. Aislamiento: cada overlay se une a un canal (?user=) y solo recibe eventos de ese canal.
// Ingesta (conectores de GREÑA LIVE): POST /event?user=X o mensaje WS {user, event}. Si GRENA_TOKEN está definido, se exige (?token= o cabecera x-token).
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), PORT = process.env.PORT || 3000, TOKEN = process.env.GRENA_TOKEN || '';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png', '.ogg': 'audio/ogg', '.woff2': 'font/woff2', '.glb': 'model/gltf-binary' };
const rooms = new Map(); const okUser = (u) => /^[\w.@-]{1,64}$/.test(u || '') ? u : null;
function broadcast(user, event) { let n = 0; for (const ws of rooms.get(user) || []) if (ws.readyState === 1) { ws.send(JSON.stringify(event)); n++; } return n; }
const authed = (tok) => !TOKEN || tok === TOKEN;
const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/healthz') { res.end('ok'); return; }
  if (req.method === 'POST' && u.pathname === '/event') {
    const user = okUser(u.searchParams.get('user')); if (!user || !authed(u.searchParams.get('token') || req.headers['x-token'])) { res.writeHead(401).end('no autorizado'); return; }
    let b = ''; req.on('data', (d) => { b += d; if (b.length > 65536) req.destroy(); });
    req.on('end', () => { try { res.end(JSON.stringify({ delivered: broadcast(user, JSON.parse(b)) })); } catch { res.writeHead(400).end('json inválido'); } }); return;
  }
  let p = u.pathname === '/' ? '/public/demo.html' : u.pathname.startsWith('/src/') ? u.pathname : '/public' + u.pathname;
  const f = path.resolve(root, '.' + decodeURIComponent(p));
  if (!f.startsWith(root + path.sep) || /(^|[\\/])(node_modules|\.git)([\\/]|$)/.test(f)) { res.writeHead(403).end(); return; }
  fs.readFile(f, (e, d) => e ? res.writeHead(404).end('no encontrado') : (res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' }), res.end(d)));
});
try {
  const { WebSocketServer } = await import('ws'); const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 65536 });
  wss.on('connection', (ws, req) => {
    const q = new URL(req.url, 'http://x').searchParams, own = okUser(q.get('user')); if (own) { if (!rooms.has(own)) rooms.set(own, new Set()); rooms.get(own).add(ws); }
    const src = authed(q.get('token'));
    ws.on('message', (m) => { if (!src) return; try { const { user, event } = JSON.parse(m); const t = okUser(user); if (t && event) broadcast(t, event); } catch { /* ignorar */ } });
    ws.on('close', () => { rooms.get(own)?.delete(ws); });
  });
} catch { console.warn('Paquete "ws" no instalado: ejecuta npm install. Solo HTTP disponible.'); }
server.listen(PORT, () => console.log(`GREÑA Dominó Alerts en http://localhost:${PORT}`));
