// Reglas del dominó doble seis. Una "cadena" es un arreglo de fichas orientadas [izq, der]
// donde der(i) === izq(i+1). Sin fichas repetidas.
import { clamp } from '../utils/hash.js';
export const TILES = []; for (let a = 0; a <= 6; a++) for (let b = a; b <= 6; b++) TILES.push([a, b]);
export const key = (t) => (t[0] < t[1] ? `${t[0]}-${t[1]}` : `${t[1]}-${t[0]}`);
export const isDouble = (t) => t[0] === t[1];
export function isValidChain(c) {
  if (!Array.isArray(c) || !c.length) return false;
  const seen = new Set();
  for (let i = 0; i < c.length; i++) {
    const t = c[i];
    if (!Array.isArray(t) || t.length !== 2 || !t.every((v) => Number.isInteger(v) && v >= 0 && v <= 6)) return false;
    const k = key(t); if (seen.has(k)) return false; seen.add(k);
    if (i && c[i - 1][1] !== t[0]) return false;
  }
  return true;
}
export const ends = (c) => [c[0][0], c[c.length - 1][1]];
// Capicúa: cierre válido con la última ficha jugable por ambos extremos (extremos iguales).
export const isCapicua = (c) => isValidChain(c) && ends(c)[0] === ends(c)[1];
// Tranque: ambos extremos abiertos con el mismo número y sus 7 fichas ya jugadas: nadie puede continuar.
export const isTranque = (c) => { if (!isValidChain(c)) return false; const [l, r] = ends(c); return l === r && c.filter((t) => t[0] === l || t[1] === l).length === 7; };
export const isPase = (hand, c) => { const [l, r] = ends(c); return !hand.some((t) => t.includes(l) || t.includes(r)); };
export const isDomino = (hand) => hand.length === 0;

function trail(len, r, closed) {
  for (let at = 0; at < 200; at++) {
    const s = Math.floor(r() * 7), used = new Set(), chain = []; let steps = 0;
    const dfs = (cur) => {
      if (chain.length === len) return !closed || cur === s;
      if (++steps > 20000) return false;
      const opts = TILES.filter((t) => !used.has(key(t)) && (t[0] === cur || t[1] === cur)).sort(() => r() - 0.5);
      for (const t of opts) { const o = t[0] === cur ? [t[0], t[1]] : [t[1], t[0]]; used.add(key(t)); chain.push(o); if (dfs(o[1])) return true; chain.pop(); used.delete(key(t)); }
      return false;
    };
    if (dfs(s)) return chain.slice();
  }
  return null;
}
/** Capicúa válida: len 1 = doble; len>=3 = recorrido cerrado (len 2 es imposible con fichas únicas). */
export function closedTrail(len, r = Math.random) {
  if (len <= 1) { const n = Math.floor(r() * 7); return [[n, n]]; }
  return trail(clamp(len, 3, 12), r, true) || [[0, 1], [1, 2], [2, 0]];
}
export const openChain = (len, r = Math.random) => trail(clamp(len, 1, 12), r, false) || [[0, 1], [1, 2]];
/** Tranque real del número n: 11 valores, extremos n/n, las 7 fichas de n sobre la mesa. */
export function tranqueChain(n, r = Math.random) {
  const o = [0, 1, 2, 3, 4, 5, 6].filter((v) => v !== n).sort(() => r() - 0.5);
  const seq = [n, n, o[0], o[1], n, o[2], o[3], n, o[4], o[5], n];
  return seq.slice(1).map((v, i) => [seq[i], v]);
}
