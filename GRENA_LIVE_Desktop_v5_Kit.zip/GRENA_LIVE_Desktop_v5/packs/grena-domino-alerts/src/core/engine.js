// Fachada del módulo: DominoAlerts. Une normalizador, cola, conversor, ajustes y renderizador.
import { normalizeEvent } from '../events/normalizer.js';
import { AlertQueue } from './queue.js';
import { GiftConverter } from '../converter/giftConverter.js';
import { SettingsStore } from '../settings/settings.js';
import { buildAlert, fallbackAlert } from '../animations/alerts.js';
export class DominoAlerts {
  constructor({ renderer = null, settings = new SettingsStore(), userId = 'default', converter, onDelegate, onError = (e) => console.error('[domino]', e) } = {}) {
    this.renderer = renderer; this.settings = settings; this.userId = userId; this.onDelegate = onDelegate; this.onError = onError; this.lastSpec = null;
    this.converter = converter || new GiftConverter({ custom: settings.get(userId).customGifts });
    this.queue = new AlertQueue({ play: (ev) => this._play(ev), onError });
  }
  /** Recibe un evento crudo de un conector de GREÑA LIVE. Devuelve queued|merged|duplicate|dropped|invalid. */
  push(raw) { let ev; try { ev = normalizeEvent(raw); } catch (e) { this.onError(e); return 'invalid'; } return this.queue.push(ev); }
  async _play(ev) {
    const st = this.settings.get(this.userId);
    if (st.style !== 'domino') { this.onDelegate?.(ev, st.style); return; }           // Original / Minecraft: los atiende GREÑA LIVE
    if (ev.type !== 'unknown' && !st.events[ev.type]?.enabled) return;
    const lay = this.renderer?.layout() ?? { W: 1920, H: 1080, unit: 108, maxUnits: 16 };
    let spec; try { spec = buildAlert(ev, { conv: this.converter, settings: st, lay }); } catch (e) { this.onError(e); spec = fallbackAlert(ev, lay, st); }
    this.lastSpec = spec; this.settings.record(this.userId, ev);
    if (this.renderer) await this.renderer.play(spec);
  }
}
