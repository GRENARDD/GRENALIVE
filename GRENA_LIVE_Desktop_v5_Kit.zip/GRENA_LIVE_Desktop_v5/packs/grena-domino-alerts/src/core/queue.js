// Cola con prioridades, deduplicación por id y agrupación de combos (los eventos en espera se funden).
export const PRIORITY = { donation: 6, gift: 5, sub: 5, raid: 4, follow: 3, unknown: 3, share: 2, like: 1 };
export class AlertQueue {
  constructor({ play, onError = () => {}, dedupeMs = 30000, now = Date.now, maxPending = 500 }) {
    Object.assign(this, { play, onError, dedupeMs, now, maxPending });
    this.items = []; this.seen = new Map(); this.playing = false; this.seq = 0;
    this.stats = { received: 0, played: 0, duplicates: 0, merged: 0, errors: 0, dropped: 0 };
  }
  _ck(e) {
    if (e.type === 'gift') return `g|${e.platform}|${e.user}|${e.gift?.id}`;
    if (e.type === 'like' || e.type === 'share') return `${e.type}|${e.platform}|${e.user}`;
    return null;
  }
  push(ev) {
    this.stats.received++; const t = this.now();
    for (const [k, ts] of this.seen) if (t - ts > this.dedupeMs) this.seen.delete(k);
    if (this.seen.has(ev.id)) { this.stats.duplicates++; return 'duplicate'; }
    this.seen.set(ev.id, t);
    const ck = this._ck(ev);
    const ex = ck && this.items.find((i) => i.ck === ck);
    if (ex) { ex.ev = { ...ex.ev, amount: ex.ev.amount + ev.amount, combo: (ex.ev.combo || 1) + 1 }; this.stats.merged++; return 'merged'; }
    if (this.items.length >= this.maxPending && (ev.type === 'like' || ev.type === 'share')) { this.stats.dropped++; return 'dropped'; }
    const item = { ev, ck, p: PRIORITY[ev.type] ?? 3, seq: this.seq++ };
    let i = this.items.findIndex((x) => x.p < item.p); if (i < 0) i = this.items.length;
    this.items.splice(i, 0, item);
    this._drain(); return 'queued';
  }
  async _drain() {
    if (this.playing) return; this.playing = true;
    while (this.items.length) {
      const { ev } = this.items.shift();
      try { await this.play(ev); this.stats.played++; } catch (e) { this.stats.errors++; this.onError(e, ev); }
    }
    this.playing = false;
  }
  get pending() { return this.items.length; }
}
