// Normaliza eventos de los conectores de GREÑA LIVE a un formato único. No llama a ninguna API de plataforma.
import { clean, safeUrl, hash, clamp } from '../utils/hash.js';
const ALIAS = {
  follow: ['follow', 'follower', 'new_follower', 'seguidor'],
  sub: ['sub', 'subscribe', 'subscription', 'subscriber', 'resub', 'membership', 'suscripcion', 'suscripción'],
  gift: ['gift', 'giftsent', 'gift_sent', 'regalo'],
  like: ['like', 'likes'], share: ['share', 'compartir'], raid: ['raid', 'host'],
  donation: ['donation', 'donate', 'tip', 'bits', 'cheer', 'donacion', 'donación'],
};
const LOOKUP = new Map(Object.entries(ALIAS).flatMap(([k, v]) => v.map((a) => [a, k])));
const PLATFORMS = ['tiktok', 'twitch', 'kick', 'starvios'];
const num = (v) => { const n = Number(v); return Number.isFinite(n) && n >= 0 ? n : null; };
export function normalizeEvent(raw, now = Date.now) {
  if (!raw || typeof raw !== 'object') throw new TypeError('Evento inválido');
  const t = String(raw.type ?? raw.event ?? raw.kind ?? '').toLowerCase().trim();
  let type = LOOKUP.get(t) || 'unknown';
  const platform = PLATFORMS.includes(String(raw.platform).toLowerCase()) ? String(raw.platform).toLowerCase() : clean(raw.platform || 'unknown', 20).toLowerCase();
  const u = raw.user;
  const user = clean((typeof u === 'string' ? u : u?.nickname || u?.name || u?.displayName) || raw.username || raw.nickname || raw.displayName || 'Anónimo') || 'Anónimo';
  const g = raw.gift || (raw.giftId || raw.giftName ? { id: raw.giftId, name: raw.giftName, image: raw.giftImage || raw.giftPictureUrl, value: raw.diamondCount } : null);
  let gift = null;
  if (g) gift = { id: clean(g.id ?? g.name ?? 'unknown', 64), name: clean(g.name ?? 'Regalo', 40) || 'Regalo', image: safeUrl(g.image ?? g.imageUrl ?? g.picture), animation: safeUrl(g.animation ?? g.animationUrl), value: num(g.value ?? g.diamondCount ?? g.coins ?? g.price) };
  if (type === 'unknown' && gift) type = 'gift';
  const amount = clamp(Math.floor(num(raw.amount ?? raw.count ?? raw.repeatCount ?? raw.likeCount ?? g?.amount) || 1), 1, 1e7);
  const bits = num(raw.bits);
  const ts = now();
  const id = clean(raw.id ?? raw.eventId ?? raw.msgId ?? '', 80) || 'auto:' + hash([type, platform, user, gift?.id, amount, Math.floor(ts / 1000)].join('|'));
  return Object.freeze({
    id, type, platform, user, amount, ts, gift,
    months: num(raw.months ?? raw.cumulativeMonths), viewers: num(raw.viewers ?? raw.viewerCount),
    origin: clean(raw.origin ?? raw.from ?? raw.fromChannel ?? '') || null,
    value: num(raw.value ?? raw.amountUsd ?? (bits != null ? bits / 100 : null)), bits, currency: clean(raw.currency ?? '', 5) || null,
    label: type === 'unknown' ? clean(t || 'evento', 30) : null,
  });
}
