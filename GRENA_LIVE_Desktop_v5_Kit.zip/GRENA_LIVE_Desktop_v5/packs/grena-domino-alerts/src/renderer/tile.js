// Ficha de dominó doble seis dibujada con volumen (cara, canto extruido, bisel, pasador de latón, puntos con brillo).
const PIPS = { 0: [], 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]],
  5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] };
function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
export function drawTile(c, a, b, u) {
  const w = u, h = 2 * u, r = u * 0.13, d = u * 0.15;
  c.save();
  rr(c, -w / 2 + d * 0.45, -h / 2 + d, w, h, r); c.fillStyle = '#9d957f'; c.fill();                 // canto (grosor)
  rr(c, -w / 2 + d * 0.2, -h / 2 + d * 0.45, w, h, r); c.fillStyle = '#cfc8b4'; c.fill();
  const g = c.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2); g.addColorStop(0, '#fffdf6'); g.addColorStop(1, '#ece5d2');
  rr(c, -w / 2, -h / 2, w, h, r); c.fillStyle = g; c.fill();                                          // cara marfil
  c.lineWidth = u * 0.022; c.strokeStyle = 'rgba(120,110,90,.55)'; c.stroke();
  rr(c, -w / 2 + u * 0.04, -h / 2 + u * 0.04, w - u * 0.08, h - u * 0.08, r * 0.8); c.strokeStyle = 'rgba(255,255,255,.8)'; c.stroke(); // bisel
  c.beginPath(); c.moveTo(-w * 0.38, 0); c.lineTo(w * 0.38, 0); c.lineWidth = u * 0.03; c.strokeStyle = 'rgba(70,60,45,.75)'; c.stroke();      // divisoria
  [[a, -1], [b, 1]].forEach(([v, s]) => {
    for (const [px, py] of PIPS[v]) {
      const x = px * u * 0.26, y = s * u * 0.5 + py * u * 0.26 * (s > 0 ? 1 : 1) * 1, rad = u * 0.085;
      const pg = c.createRadialGradient(x - rad * 0.3, y - rad * 0.3, rad * 0.1, x, y, rad);
      pg.addColorStop(0, '#555'); pg.addColorStop(0.4, '#111'); pg.addColorStop(1, '#000');
      c.beginPath(); c.arc(x, y, rad, 0, 7); c.fillStyle = pg; c.fill();
    }
  });
  if (a === 6 && b === 6) { c.beginPath(); c.arc(0, 0, u * 0.055, 0, 7); const bg = c.createRadialGradient(-u * 0.015, -u * 0.015, 0, 0, 0, u * 0.055); bg.addColorStop(0, '#fff2b0'); bg.addColorStop(1, '#a8741a'); c.fillStyle = bg; c.fill(); }
  c.restore();
}
