// Sonido: usa muestras reales si existen en assets/sounds (click.ogg, slam.ogg); si no, sintetiza (WebAudio). Sin archivos externos.
export class SoundFX {
  constructor(getVol, base = '/assets/sounds/') { this.getVol = getVol; this.base = base; this.ctx = null; this.buf = {}; this.noise = null; }
  _c() {
    if (!this.ctx) { const AC = globalThis.AudioContext || globalThis.webkitAudioContext; if (!AC) return null; this.ctx = new AC();
      const n = this.ctx.createBuffer(1, this.ctx.sampleRate * 0.3, this.ctx.sampleRate), d = n.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; this.noise = n;
      for (const k of ['click', 'slam']) fetch(`${this.base}${k}.ogg`).then((r) => (r.ok ? r.arrayBuffer() : Promise.reject())).then((a) => this.ctx.decodeAudioData(a)).then((b) => (this.buf[k] = b)).catch(() => {}); }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  }
  _env(c, t, g, dur) { const n = c.createGain(); n.gain.setValueAtTime(g, t); n.gain.exponentialRampToValueAtTime(0.0001, t + dur); n.connect(c.destination); return n; }
  _tok(c, t, v, f0, f1, dur) { const o = c.createOscillator(); o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur); o.connect(this._env(c, t, v, dur)); o.start(t); o.stop(t + dur); }
  _hit(c, t, v, freq, dur, lp) { const s = c.createBufferSource(); s.buffer = this.noise; const f = c.createBiquadFilter(); f.type = lp ? 'lowpass' : 'bandpass'; f.frequency.value = freq; f.Q.value = 1.1; s.connect(f); f.connect(this._env(c, t, v, dur)); s.start(t); s.stop(t + dur); }
  play(type, power = 0.7) {
    const v = this.getVol() * Math.min(1, power); if (v <= 0) return; const c = this._c(); if (!c) return; const t = c.currentTime;
    const kind = type === 'click' ? 'click' : 'slam';
    if (this.buf[kind]) { const s = c.createBufferSource(); s.buffer = this.buf[kind]; const g = c.createGain(); g.gain.value = v; s.connect(g); g.connect(c.destination); s.start(t); return; }
    const jit = 1 + (Math.random() - 0.5) * 0.18;
    if (type === 'click') { this._hit(c, t, v * 0.7, 2600 * jit, 0.045); this._tok(c, t, v * 0.6, 950 * jit, 420, 0.06); }
    else { this._hit(c, t, v, 900, 0.14, true); this._tok(c, t, v * 1.2, 150, 42, 0.26); this._hit(c, t, v * 0.7, 2400 * jit, 0.05); this._tok(c, t, v * 0.5, 900, 380, 0.07);
      if (type === 'lock') { this._tok(c, t + 0.16, v * 0.8, 120, 40, 0.22); this._hit(c, t + 0.16, v * 0.6, 700, 0.12, true); } }
  }
}
