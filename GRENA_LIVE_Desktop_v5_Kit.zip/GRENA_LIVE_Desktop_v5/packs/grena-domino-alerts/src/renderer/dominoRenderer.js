// Renderizador Canvas 2D (fondo 100% transparente). Un solo motor para demo.html y overlay.html.
import { drawTile } from './tile.js';
import { SoundFX } from './sound.js';
const EASE = { in: (p) => Math.pow(p, 2.2), out: (p) => 1 - Math.pow(1 - p, 3) };
const lerp = (a, b, t) => a + (b - a) * t;
const FONT = '"Arial Black","Impact","Helvetica Neue",Arial,sans-serif';
const COL = ['#ffd24a', '#ff5a5a', '#5ad1ff', '#7dff8a', '#ffffff', '#ff9bf0'];
const media = new Map();
function loadMedia(url) {
  if (media.has(url)) return media.get(url);
  const m = { ready: false, failed: false, el: null };
  if (/\.(webm|mp4)(\?|$)/i.test(url)) { const v = document.createElement('video'); Object.assign(v, { muted: true, loop: true, playsInline: true, crossOrigin: 'anonymous' }); v.onloadeddata = () => { m.ready = true; v.play().catch(() => {}); }; v.onerror = () => (m.failed = true); v.src = url; m.el = v; }
  else { const i = new Image(); i.crossOrigin = 'anonymous'; i.onload = () => (m.ready = true); i.onerror = () => (m.failed = true); i.src = url; m.el = i; }
  media.set(url, m);
  if (media.size > 60) { const k = media.keys().next().value, o = media.get(k); if (o.el?.pause) { o.el.pause(); o.el.removeAttribute('src'); } media.delete(k); }
  return m;
}
export class DominoRenderer {
  constructor(canvas, { getSettings, orientation = 'horizontal' }) {
    this.canvas = canvas; this.ctx = canvas.getContext('2d', { alpha: true }); this.getSettings = getSettings;
    this.sound = new SoundFX(() => this.getSettings().volume); this.fps = 0; this.setOrientation(orientation); this._loop = this._loop.bind(this);
  }
  setOrientation(o) { this.orientation = o; this.W = o === 'vertical' ? 1080 : 1920; this.H = o === 'vertical' ? 1920 : 1080; this.canvas.width = this.W; this.canvas.height = this.H; }
  unit() { return Math.min(this.W, this.H) * 0.1 * this.getSettings().size; }
  layout() { const unit = this.unit(); return { W: this.W, H: this.H, unit, maxUnits: (this.W * 0.9) / unit }; }
  cancel() { cancelAnimationFrame(this.raf); this.raf = 0; this.parts = []; this.ctx.clearRect(0, 0, this.W, this.H); this._res?.(); this._res = null; this.spec = null; }
  play(spec) {
    return new Promise((res) => {
      this.cancel(); this._res = res; this.spec = spec; this.t0 = performance.now(); this.last = this.t0; this.fired = new Set(); this.bf = new Set();
      this.parts = []; this.shake = 0; this.flash = 0; this.fx = 0; this.fy = 0; this.mediaObj = spec.media ? loadMedia(spec.media.url) : null;
      this.raf = requestAnimationFrame(this._loop);
    });
  }
  _loop(now) {
    const s = this.spec; if (!s) return;
    const t = (now - this.t0) / 1000, dt = Math.min(0.05, (now - this.last) / 1000); this.last = now; this.fps = lerp(this.fps || 60, 1 / Math.max(dt, 0.001), 0.05);
    this._update(t, dt); this._draw(t);
    if (t >= s.duration) { this.raf = 0; this.ctx.clearRect(0, 0, this.W, this.H); this.spec = null; const r = this._res; this._res = null; r?.(); return; }
    this.raf = requestAnimationFrame(this._loop);
  }
  _state(k, t) {
    const tt = t - k.delay; if (tt < 0) return k.hold ? { x: k.fx, y: k.fy, r: k.fr, s: k.fs, air: 0 } : null;
    const p = Math.min(1, tt / k.dur), e = EASE[k.ease](p); let s = lerp(k.fs, k.ts, e);
    if (p >= 1) { const q = (tt - k.dur) / 0.18; if (q < 1) s *= 1 + 0.07 * Math.sin(Math.PI * q); }
    return { x: lerp(k.fx, k.tx, e), y: lerp(k.fy, k.ty, e), r: lerp(k.fr, k.tr, e), s, air: 1 - p };
  }
  _burst(x, y, n, kind, u) {
    const st = this.getSettings(); if (!st.effects.particles) return; n = Math.min(Math.floor(n), 120);
    for (let i = 0; i < n && this.parts.length < 500; i++) { const a = Math.random() * 6.283, v = u * (kind === 'confetti' ? 2 + Math.random() * 7 : 3 + Math.random() * 9);
      this.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - (kind === 'confetti' ? u * 7 : u * 2), life: 0, max: 0.6 + Math.random() * 0.8, sz: u * (kind === 'confetti' ? 0.09 : 0.04 + Math.random() * 0.04), c: kind === 'confetti' ? COL[i % COL.length] : Math.random() < 0.6 ? '#ffe28a' : '#fff', k: kind, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 12 }); }
  }
  _update(t, dt) {
    const s = this.spec, u = this.unit(), st = this.getSettings();
    s.tiles.forEach((k, i) => {
      if (this.fired.has(i) || t < k.delay + k.dur) return; this.fired.add(i);
      this.sound.play(k.snd, 0.35 + k.power * 0.65);
      if (st.effects.shake) this.shake = Math.max(this.shake, k.shake);
      this._burst(k.tx * u, k.ty * u, 6 + k.power * 22, 'sparks', u);
      if (k.power >= 0.9 && st.effects.flash) { this.flash = 1; this.fx = k.tx * u; this.fy = k.ty * u; }
    });
    s.bursts.forEach((b, i) => { if (!this.bf.has(i) && t >= b.t) { this.bf.add(i); this._burst(b.x * u, b.y * u, b.n, b.kind, u); if (b.kind === 'sparks' && st.effects.flash) { this.flash = 0.8; this.fx = b.x * u; this.fy = b.y * u; } } });
    for (const p of this.parts) { p.life += dt; p.vy += u * 14 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt; }
    this.parts = this.parts.filter((p) => p.life < p.max); this.shake *= Math.exp(-dt * 7); this.flash *= Math.exp(-dt * 6);
  }
  _draw(t) {
    const { ctx: c, W, H } = this, s = this.spec, u = this.unit(), st = this.getSettings(), pos = st.position[this.orientation];
    c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, W, H); c.save();
    c.globalAlpha = Math.max(0, Math.min(1, (s.duration - t) / 0.5));
    const sh = this.shake * u * 0.12; c.translate(W * pos.x + (Math.random() - 0.5) * sh, H * pos.y + (Math.random() - 0.5) * sh);
    if (st.felt && s.felt) { const a = Math.min(1, t / 0.3), rx = s.felt.rx * u, ry = s.felt.ry * u, g = c.createRadialGradient(0, 0, 0, 0, 0, rx);
      g.addColorStop(0, 'rgba(22,110,62,.88)'); g.addColorStop(0.7, 'rgba(14,78,44,.7)'); g.addColorStop(1, 'rgba(14,78,44,0)');
      c.save(); c.globalAlpha *= a; c.scale(1, ry / rx); c.fillStyle = g; c.beginPath(); c.arc(0, 0, rx, 0, 7); c.fill(); c.restore(); }
    if (s.media && this.mediaObj?.ready && t > s.media.delay) { const m = this.mediaObj, q = Math.min(1, (t - s.media.delay) / 0.35), sz = s.media.size * u * (0.6 + 0.4 * EASE.out(q));
      const el = m.el, w = el.videoWidth || el.naturalWidth || 1, h = el.videoHeight || el.naturalHeight || 1, k = Math.min(sz / w, sz / h), by = s.media.y * u + Math.sin(t * 3) * u * 0.06;
      c.save(); c.globalAlpha *= q; const g = c.createRadialGradient(0, by, 0, 0, by, sz * 0.62); g.addColorStop(0, 'rgba(255,214,90,.55)'); g.addColorStop(1, 'rgba(255,214,90,0)');
      c.fillStyle = g; c.beginPath(); c.arc(0, by, sz * 0.62, 0, 7); c.fill(); try { c.drawImage(el, -w * k / 2, by - h * k / 2, w * k, h * k); } catch { /* recurso no dibujable */ } c.restore(); }
    const list = s.tiles.map((k) => ({ k, v: this._state(k, t) })).filter((o) => o.v).sort((a, b) => b.v.air - a.v.air);
    for (const { v } of list) { // sombras en la mesa
      c.save(); c.globalAlpha *= 0.32 / Math.max(1, v.s * 0.8); c.fillStyle = '#000'; c.translate(v.x * u + u * 0.12 * v.s, v.y * u + u * 0.2 * v.s);
      c.rotate(v.r); c.scale(1, 1); const w = u * v.s; c.beginPath(); c.ellipse(0, 0, w * 0.55, w * 1.05, 0, 0, 7); c.fill(); c.restore(); }
    for (const { k, v } of list) { c.save(); c.translate(v.x * u, v.y * u); c.rotate(v.r); drawTile(c, k.a, k.b, u * v.s); c.restore(); }
    if (this.flash > 0.02 && st.effects.flash) { c.save(); c.globalCompositeOperation = 'lighter'; const g = c.createRadialGradient(this.fx, this.fy, 0, this.fx, this.fy, u * 6);
      g.addColorStop(0, `rgba(255,236,170,${this.flash * 0.6})`); g.addColorStop(1, 'rgba(255,236,170,0)'); c.fillStyle = g; c.beginPath(); c.arc(this.fx, this.fy, u * 6, 0, 7); c.fill(); c.restore(); }
    for (const p of this.parts) { const a = 1 - p.life / p.max; c.globalAlpha = Math.max(0, a) * Math.max(0, Math.min(1, (s.duration - t) / 0.5)); c.fillStyle = p.c;
      if (p.k === 'confetti') { c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.fillRect(-p.sz, -p.sz * 0.5, p.sz * 2, p.sz); c.restore(); } else { c.beginPath(); c.arc(p.x, p.y, p.sz * a + 1, 0, 7); c.fill(); } }
    c.globalAlpha = Math.max(0, Math.min(1, (s.duration - t) / 0.5));
    for (const x of s.texts) {
      const tt = t - x.delay; if (tt < 0) continue; const a = Math.min(1, tt / 0.25); let size = x.size * u; c.font = `900 ${size}px ${FONT}`;
      const w = c.measureText(x.t).width, mx = W * 0.94 / Math.max(0.3, st.size > 1 ? 1 : 1); if (w > mx) { size *= mx / w; c.font = `900 ${size}px ${FONT}`; }
      c.save(); c.globalAlpha *= a; c.translate(0, x.y * u); const sc = 0.8 + 0.2 * EASE.out(a); c.scale(sc, sc); c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round';
      c.lineWidth = size * 0.2; c.strokeStyle = 'rgba(10,10,10,.92)'; c.strokeText(x.t, 0, 0);
      if (x.gold) { const g = c.createLinearGradient(0, -size / 2, 0, size / 2); g.addColorStop(0, '#fff6c8'); g.addColorStop(1, '#f2b632'); c.fillStyle = g; } else c.fillStyle = '#fff';
      c.fillText(x.t, 0, 0); c.restore();
    }
    c.restore();
  }
}
