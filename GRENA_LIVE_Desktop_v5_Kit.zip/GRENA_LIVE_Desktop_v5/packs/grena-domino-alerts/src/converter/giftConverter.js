// Dominó Gift Converter: cualquier regalo (conocido o no) -> parámetros de animación, sin código por regalo.
import { clamp } from '../utils/hash.js';
const COUNT = { small: 1, medium: 5, large: 9 };
export class GiftConverter {
  constructor({ tiers = { small: 100, medium: 1000 }, custom = {} } = {}) { this.tiers = tiers; this.custom = custom; this.cache = new Map(); }
  setCustom(key, v) { this.custom[key] = v; this.cache.clear(); }          // key: "plataforma:id" o "*:id"; v: {tier?, name?}
  convert(gift, amount = 1, platform = 'unknown', tiers = this.tiers) {
    const g = gift || {}; const id = g.id || g.name || 'unknown'; const key = `${platform}:${id}`;
    let base = this.cache.get(key);
    if (!base) {
      base = { key, name: g.name || 'Regalo', image: g.image || null, animation: g.animation || null, unitValue: g.value ?? null, custom: this.custom[key] || this.custom[`*:${id}`] || null };
      if (this.cache.size > 500) this.cache.delete(this.cache.keys().next().value);
      this.cache.set(key, base);
    }
    const total = base.unitValue != null ? base.unitValue * amount : null;
    let tier = base.custom?.tier;
    if (!tier) tier = total == null ? (amount < 5 ? 'small' : amount < 25 ? 'medium' : 'large') : total < tiers.small ? 'small' : total < tiers.medium ? 'medium' : 'large';
    return { key, tier, count: COUNT[tier], name: base.custom?.name || base.name, image: base.image, animation: base.animation,
      amount, total, fallback: !base.image && !base.animation, intensity: clamp(total != null ? Math.log10(total + 1) / 4 : amount / 50, 0.1, 1) };
  }
}
