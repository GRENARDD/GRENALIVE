// Constructor de alertas: evento normalizado -> "spec" declarativo (fichas + textos + efectos).
// Unidades: 1u = ancho de una ficha. Coordenadas relativas al ancla (centro de la alerta).
import { closedTrail, openChain, tranqueChain, isDouble, isCapicua, isTranque, isValidChain } from '../core/domino.js';
import { rng, hash, clamp } from '../utils/hash.js';
const PL = { tiktok: 'TikTok', twitch: 'Twitch', kick: 'Kick', starvios: 'Starvios' };
const plat = (p) => PL[p] || (p && p !== 'unknown' ? p : '');
const tile = (a, b, o) => ({ a, b, delay: 0, dur: 0.5, fx: 0, fy: -9, fr: 0, fs: 2.4, tx: 0, ty: 0, tr: 0, ts: 1, ease: 'in', hold: false, power: 0.5, shake: 0.35, snd: 'click', ...o });
const T = (t, y, size, delay, gold = false) => ({ t, y, size, delay, gold });
const spin = (r) => (r() < 0.5 ? -1 : 1) * Math.PI * (1 + Math.floor(r() * 2));

function layoutChain(chain, lay, r, { step = 0.15, start = 0.15, y = 0 } = {}) {
  const span = chain.reduce((s, t) => s + (isDouble(t) ? 1 : 2), 0);
  const sc = Math.min(1, (lay.maxUnits * 0.92) / span), total = span * sc;
  let x = -total / 2;
  return chain.map((t, i) => {
    const w = (isDouble(t) ? 1 : 2) * sc, last = i === chain.length - 1;
    const o = tile(t[0], t[1], { delay: start + i * step, dur: 0.42, fx: x + w / 2, fy: -8, fr: spin(r), fs: 2.2, tx: x + w / 2, ty: y, tr: isDouble(t) ? 0 : -Math.PI / 2, ts: sc,
      power: last ? 1 : 0.45, shake: last ? 1 : 0.3, snd: last ? 'slam' : 'click' });
    x += w; return o;
  });
}
const endTime = (tiles) => Math.max(...tiles.map((k) => k.delay + k.dur));
const finish = (ev, cfg, spec) => ({ type: ev.type, bursts: [], texts: [], felt: null, media: null, meta: {}, ...spec, duration: (endTime(spec.tiles) + (spec.hold ?? 2.4)) * (cfg.duration || 1) });

export function buildAlert(ev, { conv, settings, lay }) {
  const cfg = settings.events[ev.type] || { title: '¡NUEVO EVENTO!', duration: 1 };
  const r = rng(hash(ev.id)), P = plat(ev.platform), title = cfg.title;
  switch (ev.type) {
    case 'follow': {
      const tiles = [tile(6, 6, { delay: 0.15, dur: 0.5, fr: Math.PI * 3, fs: 2.8, ts: 1.15, power: 1, shake: 1, snd: 'slam' })];
      return finish(ev, cfg, { tiles, felt: { rx: 6, ry: 3.4 }, bursts: [{ t: 0.65, n: 36, kind: 'sparks', x: 0, y: 0 }],
        texts: [T(title, -3, 0.62, 0.55, true), T(ev.user, 2.7, 0.44, 0.85), T(P, 3.4, 0.28, 1)], meta: { tile: [6, 6] } });
    }
    case 'sub': {
      const n = hash(ev.user) % 7, chain = tranqueChain(n, r);
      if (!isTranque(chain)) throw new Error('tranque inválido');
      const tiles = layoutChain(chain, lay, r, { step: 0.17 });
      const m = ev.months ? `${ev.months} ${ev.months === 1 ? 'mes' : 'meses'} · ` : '';
      return finish(ev, cfg, { tiles, felt: { rx: 9, ry: 3.6 }, bursts: [{ t: endTime(tiles), n: 40, kind: 'sparks', x: 0, y: 0 }],
        texts: [T(title, -3, 0.62, 0.4, true), T(ev.user, 2.7, 0.44, 0.9), T(m + P, 3.4, 0.28, 1)], meta: { chain, claim: 'tranque', n } });
    }
    case 'gift': {
      const g = conv.convert(ev.gift, ev.amount, ev.platform, settings.giftTiers);
      const chain = closedTrail(g.count, r);
      if (!isCapicua(chain)) throw new Error('capicúa inválida');
      const tiles = layoutChain(chain, lay, r, { step: g.tier === 'large' ? 0.11 : 0.16 });
      const end = endTime(tiles), url = g.animation || g.image;
      const bursts = [{ t: end, n: 30 + g.intensity * 50, kind: 'sparks', x: 0, y: 0 }];
      if (g.tier !== 'small') bursts.push({ t: end + 0.05, n: 40, kind: 'confetti', x: 0, y: -3 });
      if (g.tier === 'large') bursts.push({ t: end + 0.5, n: 60, kind: 'confetti', x: 0, y: -3 });
      const ty = url ? -3.3 : -2.7;
      return finish(ev, cfg, { tiles, bursts, felt: { rx: 9, ry: 3.8 }, media: url ? { url, y: -6.1, size: 2.8, delay: 0.1 } : null,
        texts: [T(title, ty, 0.62, 0.3, true), T(`${ev.user} envió ${g.name}${ev.amount > 1 ? ' ×' + ev.amount : ''}`, 2.7, 0.42, 0.7), T(P, 3.4, 0.28, 0.9)],
        meta: { chain, claim: 'capicua', tier: g.tier, fallback: g.fallback } });
    }
    case 'like': {
      const n = clamp(3 + Math.floor(Math.sqrt(ev.amount) * 1.4), 3, 26), it = n / 26;
      const tiles = Array.from({ length: n }, (_, i) => tile(Math.floor(r() * 7), Math.floor(r() * 7), { delay: 0.1 + i * (1.3 / n), dur: 0.38, fx: (r() - 0.5) * 8, fr: spin(r), fs: 2.2,
        tx: (r() - 0.5) * 8, ty: 0.4 + r() * 2.2, tr: (r() - 0.5) * 6, power: 0.3 + 0.4 * it, shake: 0.12 + 0.3 * it }));
      tiles.forEach((k) => (k.fx = k.tx));
      return finish(ev, cfg, { tiles, hold: 2, texts: [T(title, -3, 0.58, 0.3, true), T(`${ev.user} · ${ev.amount} likes`, 5.2, 0.4, 0.6)], meta: { count: n } });
    }
    case 'share': {
      const n = 6, sp = Math.min(1.6, (lay.maxUnits * 0.8) / n), sx = -((n - 1) * sp) / 2;
      const tiles = [tile(Math.floor(r() * 7), Math.floor(r() * 7), { delay: 0, dur: 0.4, fx: sx - 1.2, fr: 0, tx: sx - 1.3, ty: -0.2, tr: 0.45, ts: 0.9, power: 0.5 })];
      for (let i = 0; i < n; i++) tiles.push(tile(Math.floor(r() * 7), Math.floor(r() * 7), { delay: 0.45 + i * 0.17, dur: 0.34, hold: true, fx: sx + i * sp, fy: 0, fr: 0, fs: 0.9,
        tx: sx + i * sp + 0.3, ty: 0.1, tr: 1.3, ts: 0.9, power: 0.35, shake: 0.12 }));
      return finish(ev, cfg, { tiles, bursts: [{ t: endTime(tiles), n: 24, kind: 'sparks', x: 0, y: 0 }], texts: [T(title, -3.2, 0.6, 0.3, true), T(ev.user, 2.9, 0.42, 0.7), T(P, 3.6, 0.28, 0.9)] });
    }
    case 'raid': {
      const n = clamp(4 + Math.floor((ev.viewers || 0) / 50), 4, 12), sc = Math.min(1, (lay.maxUnits * 0.9) / (n * 1.3)), sp = 1.3 * sc;
      const tiles = Array.from({ length: n }, (_, i) => tile(Math.floor(r() * 7), Math.floor(r() * 7), { delay: 0.1 + i * 0.12, dur: 0.55, ease: 'out', fx: lay.maxUnits, fy: 0, fr: 0.3,
        tx: -((n - 1) * sp) / 2 + i * sp, ty: 0, tr: 0, ts: sc, power: 0.3 + (i === n - 1) * 0.6, shake: 0.15 + (i === n - 1) * 0.6, snd: i === n - 1 ? 'slam' : 'click', fs: sc }));
      return finish(ev, cfg, { tiles, bursts: [{ t: endTime(tiles), n: 40, kind: 'sparks', x: 0, y: 0 }],
        texts: [T(title, -2.8, 0.62, 0.3, true), T(`${ev.origin || ev.user}${ev.viewers ? ' · ' + ev.viewers + ' espectadores' : ''}`, 2.6, 0.42, 0.9), T(P, 3.3, 0.28, 1)], meta: { count: n } });
    }
    case 'donation': {
      const v = ev.value ?? 0, len = v < 5 ? 4 : v < 50 ? 6 : 9;
      const chain = openChain(len, r); if (!isValidChain(chain)) throw new Error('cadena inválida');
      const tiles = layoutChain(chain, lay, r, { step: 0.17 });
      const big = v >= 50, end = endTime(tiles);
      const amt = ev.bits ? `${ev.bits} bits` : ev.value != null ? `${ev.currency || '$'}${ev.value.toFixed(2)}` : '';
      return finish(ev, cfg, { tiles, felt: { rx: 9, ry: 3.6 }, bursts: [{ t: end, n: 50, kind: 'sparks', x: 0, y: 0 }, ...(big ? [{ t: end + 0.1, n: 70, kind: 'confetti', x: 0, y: -3 }] : [])],
        texts: [T(title, -2.7, 0.66, 0.3, true), T(`${ev.user}${amt ? ' · ' + amt : ''}`, 2.7, 0.44, 0.8), T(P, 3.4, 0.28, 1)], meta: { chain } });
    }
    default: return fallbackAlert(ev, lay, settings);
  }
}
/** Respaldo: nunca se pierde un evento. */
export function fallbackAlert(ev, lay, settings) {
  const r = rng(hash(ev.id || 'x')), g = ev.gift;
  const line = g ? `${ev.user} · ${g.name}${ev.amount > 1 ? ' ×' + ev.amount : ''}` : `${ev.user}${ev.label ? ' · ' + ev.label : ''}${ev.amount > 1 ? ' ×' + ev.amount : ''}`;
  const tiles = [tile(Math.floor(r() * 7), Math.floor(r() * 7), { delay: 0.1, dur: 0.5, fr: Math.PI * 2, fs: 2.6, ts: 1.1, power: 0.8, shake: 0.7, snd: 'slam' })];
  return finish(ev, settings?.events?.[ev.type] || {}, { tiles, felt: { rx: 6, ry: 3.4 }, texts: [T('¡NUEVO EVENTO!', -3, 0.58, 0.4, true), T(line, 2.7, 0.42, 0.7), T(plat(ev.platform), 3.4, 0.28, 0.9)], meta: { fallback: true } });
}
