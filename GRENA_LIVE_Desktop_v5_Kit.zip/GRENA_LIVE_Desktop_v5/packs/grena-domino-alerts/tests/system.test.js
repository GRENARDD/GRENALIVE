import test from 'node:test'; import assert from 'node:assert/strict';
import { normalizeEvent } from '../src/events/normalizer.js';
import { AlertQueue } from '../src/core/queue.js';
import { GiftConverter } from '../src/converter/giftConverter.js';
import { SettingsStore } from '../src/settings/settings.js';
import { buildAlert } from '../src/animations/alerts.js';
import { DominoAlerts } from '../src/core/engine.js';
import { isCapicua, isTranque } from '../src/core/domino.js';
const lay = { W: 1080, H: 1920, unit: 108, maxUnits: 10 };
const st = new SettingsStore().get('t'), conv = new GiftConverter();
test('normalizador: alias, plataforma, sanitización y regalo desconocido', () => {
  const e = normalizeEvent({ type: 'Follower', platform: 'TikTok', user: { nickname: '<b>Ana</b>' } });
  assert.equal(e.type, 'follow'); assert.equal(e.platform, 'tiktok'); assert.equal(e.user, 'bAna/b');
  assert.equal(normalizeEvent({ giftName: 'X', giftId: 9, user: 'a' }).type, 'gift');
  assert.equal(normalizeEvent({ type: 'cosa-rara', user: 'a' }).type, 'unknown');
  assert.equal(normalizeEvent({ type: 'gift', gift: { id: 1, image: 'javascript:alert(1)' } }).gift.image, null);
  assert.throws(() => normalizeEvent(null));
});
test('cola: duplicados, combos y prioridades', async () => {
  const played = []; const q = new AlertQueue({ play: async (e) => { played.push(e); await new Promise((r) => setTimeout(r, 5)); } });
  const g = (id, amount = 1) => normalizeEvent({ id, type: 'gift', platform: 'kick', user: 'u', amount, gift: { id: 'r', name: 'R' } });
  q.push(normalizeEvent({ id: 'a', type: 'follow', user: 'x' })); // empieza a reproducirse
  assert.equal(q.push(normalizeEvent({ id: 'a', type: 'follow', user: 'x' })), 'duplicate');
  q.push(normalizeEvent({ id: 'l', type: 'like', user: 'y', amount: 5 })); q.push(g('g1', 2)); assert.equal(q.push(g('g2', 3)), 'merged');
  for (let i = 0; i < 100 && q.stats.played < 3; i++) await new Promise((r) => setTimeout(r, 10));
  assert.deepEqual(played.map((e) => e.type), ['follow', 'gift', 'like']); assert.equal(played[1].amount, 5);
});
test('cola: un error no detiene la cola', async () => {
  let n = 0; const q = new AlertQueue({ play: async () => { if (n++ === 0) throw new Error('x'); }, onError: () => {} });
  q.push(normalizeEvent({ id: '1', type: 'follow', user: 'a' })); q.push(normalizeEvent({ id: '2', type: 'follow', user: 'a' }));
  await new Promise((r) => setTimeout(r, 20)); assert.equal(q.stats.errors, 1); assert.equal(q.stats.played, 1);
});
test('conversor: niveles, personalizados, caché y regalos sin imagen', () => {
  const c = new GiftConverter(); assert.equal(c.convert({ id: 'a', value: 1 }, 1, 'tiktok').tier, 'small'); assert.equal(c.convert({ id: 'a', value: 1 }, 500, 'tiktok').tier, 'medium');
  assert.equal(c.convert({ id: 'b', value: 30000 }, 1, 'tiktok').tier, 'large'); assert.equal(c.convert({ id: 'z', name: 'Nuevo' }, 1, 'kick').fallback, true);
  c.setCustom('*:a', { tier: 'large' }); assert.equal(c.convert({ id: 'a', value: 1 }, 1, 'tiktok').tier, 'large');
});
test('ajustes: aislamiento por usuario, validación y prototipos', () => {
  const s = new SettingsStore(); s.set('A', { volume: 0.2, __proto__: { x: 1 } }); s.set('A', JSON.parse('{"__proto__":{"polluted":1}}'));
  assert.equal(s.get('A').volume, 0.2); assert.equal(s.get('B').volume, 0.8); assert.equal({}.polluted, undefined); assert.equal(s.set('A', { volume: 9 }).volume, 1);
});
test('alertas: todas las jugadas anunciadas son válidas', () => {
  for (let i = 0; i < 40; i++) {
    const ev = (o) => normalizeEvent({ id: 'e' + i + o.type, user: 'user' + i, platform: 'twitch', ...o });
    const sub = buildAlert(ev({ type: 'sub', months: 3 }), { conv, settings: st, lay }); assert.ok(isTranque(sub.meta.chain));
    for (const gift of [{ id: 'p', value: 1 }, { id: 'm', value: 300 }, { id: 'g', value: 9000 }, { id: 'u' }]) {
      const g = buildAlert(ev({ type: 'gift', gift }), { conv, settings: st, lay }); assert.ok(isCapicua(g.meta.chain)); assert.ok(g.texts[0].t.includes('CAPICÚA'));
    }
    for (const t of ['follow', 'like', 'share', 'raid', 'donation', 'weird']) { const a = buildAlert(ev({ type: t, amount: 50, viewers: 400, value: 80 }), { conv, settings: st, lay }); assert.ok(a.duration > 1 && a.tiles.length >= 1); }
  }
});
test('motor: respeta estilo Minecraft/Original (delegación) y eventos desactivados', async () => {
  const s = new SettingsStore(); const got = []; const eng = new DominoAlerts({ settings: s, userId: 'u', onDelegate: (e, style) => got.push(style) });
  s.set('u', { style: 'minecraft' }); eng.push({ type: 'follow', user: 'a', id: '1' }); await new Promise((r) => setTimeout(r, 10)); assert.deepEqual(got, ['minecraft']);
  s.set('u', { style: 'domino', events: { follow: { enabled: false } } }); eng.lastSpec = null; eng.push({ type: 'follow', user: 'a', id: '2' }); await new Promise((r) => setTimeout(r, 10)); assert.equal(eng.lastSpec, null);
  eng.push({ type: 'sub', user: 'a', id: '3' }); await new Promise((r) => setTimeout(r, 10)); assert.equal(eng.lastSpec.type, 'sub');
  assert.equal(eng.push('basura'), 'invalid');
});
