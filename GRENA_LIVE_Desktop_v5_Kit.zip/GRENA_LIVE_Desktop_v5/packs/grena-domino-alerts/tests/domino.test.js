import test from 'node:test'; import assert from 'node:assert/strict';
import { TILES, isValidChain, isCapicua, isTranque, isPase, isDomino, closedTrail, openChain, tranqueChain, key } from '../src/core/domino.js';
import { rng } from '../src/utils/hash.js';
test('doble seis tiene 28 fichas únicas', () => { assert.equal(TILES.length, 28); assert.equal(new Set(TILES.map(key)).size, 28); });
test('cadenas inválidas se rechazan', () => {
  assert.equal(isValidChain([[1, 2], [3, 4]]), false); assert.equal(isValidChain([[1, 2], [2, 1], [1, 2]]), false); assert.equal(isValidChain([[7, 1]]), false);
  assert.equal(isCapicua([[1, 2], [2, 3]]), false); assert.equal(isCapicua([[1, 2], [2, 3]]), false);
});
test('capicúa: doble y recorridos cerrados', () => {
  assert.ok(isCapicua([[4, 4]])); assert.ok(isCapicua([[0, 1], [1, 2], [2, 0]]));
  for (let s = 1; s < 60; s++) for (const len of [1, 3, 5, 9]) { const c = closedTrail(len, rng(s)); assert.ok(isCapicua(c), `len ${len} seed ${s}`); if (len > 1) assert.equal(c.length, len); }
});
test('tranque real para los 7 números', () => { for (let n = 0; n <= 6; n++) for (let s = 0; s < 20; s++) { const c = tranqueChain(n, rng(s)); assert.ok(isTranque(c)); assert.ok(isCapicua(c)); } assert.equal(isTranque([[0, 1], [1, 0]]), false); });
test('cadenas abiertas válidas', () => { for (let s = 0; s < 40; s++) assert.ok(isValidChain(openChain(6, rng(s)))); });
test('pase y dominó', () => { assert.ok(isPase([[0, 0]], [[1, 2]])); assert.equal(isPase([[1, 5]], [[1, 2]]), false); assert.ok(isDomino([])); });
