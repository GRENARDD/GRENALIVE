# Integración con GREÑA LIVE

No modifica GREÑA LIVE. Los conectores existentes entregan eventos; este módulo no llama a APIs de TikTok/Twitch/Kick/Starvios.

## Instalación y ejecución
`npm install && npm start` (Node ≥18). Puerto: `PORT`. Pruebas: `npm test`.

## Motor
`src/core/engine.js`: `new DominoAlerts({renderer, settings, userId, converter, onDelegate, onError}).push(rawEvent)`.
Flujo: normalizador → cola (prioridad, dedupe 30 s por `id`, combos) → ajustes del usuario → `buildAlert` (spec declarativo) → `DominoRenderer`. Si `buildAlert` falla se usa `fallbackAlert`. Sin renderizador (Node) guarda `lastSpec`.

## Conexión WebSocket / HTTP
- Overlay: `wss://HOST/ws?user=ID` (solo recibe eventos de su canal).
- Conector → módulo: `POST /event?user=ID&token=…` con el JSON, o mensaje WS `{ "user": "ID", "event": {…} }` desde una conexión con `?token=…`. Define `GRENA_TOKEN` en producción.
- Mensaje `{ "settings": {…} }` actualiza ajustes del overlay.

## Normalización
Acepta (con alias): `type` (follow, sub, gift, like, share, raid, donation/bits), `platform`, `user|username|nickname`, `amount|count|repeatCount`, `gift{id,name,image,animation,value}`, `months`, `viewers`, `origin`, `value`, `bits`, `currency`, `id`. Tipo desconocido → alerta genérica (no se pierde). Sin `id` se deriva de tipo+plataforma+usuario+regalo+cantidad+segundo (pide `id` al conector para exactitud). Solo se muestra lo que el conector entregue; imágenes solo `http(s)` o `data:image`.

## Regalos desconocidos
`GiftConverter`: nivel por `valor×cantidad` (`giftTiers`, por defecto 100/1000; sin valor, por cantidad). Pequeño=1 ficha, medio=5, grande=9, siempre capicúa válida. Imagen/animación (`png/gif/webp/webm/mp4`) en medallón; sin ellas, nombre y cantidad. Personalizar: `converter.setCustom('tiktok:rose', {tier:'large', name:'Rosa'})` o `'*:id'`. Caché de 500 entradas.

## OBS
Fuente de navegador con fondo transparente.
- Horizontal 1920×1080: `overlay.html?user=ID&orientation=horizontal`
- Vertical 1080×1920: `…&orientation=vertical&y=0.8` (posición independiente por orientación; por defecto abajo, para no tapar la cara).
- Parámetros: `x`, `y` (0–1), `size`, `volume`, `ws`, `token`.

## Selector Original | Minecraft | Dominó
`settings.style`. Si no es `domino`, el motor no dibuja y llama `onDelegate(evento, estilo)` (en el overlay, evento DOM `grena:delegate`); GREÑA LIVE debe encaminarlo a sus renderizadores existentes.

## Aislamiento de usuarios
Ajustes y estadísticas con prefijo por `userId` (`/^[\w.@-]{1,64}$/`), canales WS separados, protección contra `__proto__`. El almacenamiento es inyectable (`SettingsStore(storage)`): usa tu BD en producción (hoy `localStorage` en navegador, memoria en Node).

## Railway
Start `npm start`; variables `PORT` (automática) y `GRENA_TOKEN`. Salud: `/healthz`. Los ajustes viven en el navegador del overlay hasta que conectes un almacén.

## Limitaciones
Sin Three.js/GLB aún; audio sintetizado; sin verificación en navegador/OBS en este entorno; Original/Minecraft no incluidos; cola por overlay (una alerta a la vez); sin límite de tasa en el servidor.
