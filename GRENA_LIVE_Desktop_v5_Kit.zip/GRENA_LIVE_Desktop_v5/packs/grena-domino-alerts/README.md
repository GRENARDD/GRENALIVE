# GREÑA Dominó Alerts (v0.1)

Tercer estilo de alertas (Original | Minecraft | **Dominó**) para GREÑA LIVE. Módulo autónomo: Node.js + WebSocket + Canvas 2D, fondo transparente.

## Uso rápido
```
npm install
npm start          # http://localhost:3000  (simulador)
npm test           # reglas, cola, normalizador, conversor, ajustes y alertas
```
Overlay para OBS: `http://localhost:3000/overlay.html?user=MI_ID&orientation=horizontal` (o `vertical`).

## Estado real
| Hecho y probado con `npm test` | Hecho, **no verificado visualmente** | Pendiente |
|---|---|---|
| Reglas doble seis, capicúa, tranque, pase, dominó | Renderizado Canvas y animaciones de los 7 eventos | Modelos 3D reales con Three.js/WebGL (hoy: fichas 2.5D dibujadas con canto, sombra y escala) |
| Normalizador; cola con prioridad, duplicados y combos | Sonido sintetizado | Sonidos grabados auténticos (añadir a `assets/sounds`) |
| Conversor de regalos; ajustes por usuario | Demo, overlay y panel | Medir 60 FPS en OBS; afinar a ojo; pruebas en navegador |
| Las alertas solo anuncian jugadas válidas | Servidor HTTP probado; WebSocket requiere `npm install` | Estilos Original/Minecraft (solo se delega con `onDelegate`) |

El entorno donde se generó no tenía navegador: lo visual y el audio **no se han visto ni oído**. Abre `demo.html` y ajusta.

## Reglas aplicadas
- **Capicúa**: cadena válida con los dos extremos iguales (un doble solo es capicúa de una ficha). Longitud 1 o ≥3 (con fichas únicas, 2 es imposible).
- **Tranque**: extremos iguales y las 7 fichas de ese número ya jugadas; se genera y verifica con `isTranque`.
- Si un generador produjera una jugada inválida se usa la alerta de respaldo: nunca se rotula «capicúa» en falso.
